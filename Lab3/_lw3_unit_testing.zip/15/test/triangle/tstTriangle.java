 
import org.testng.Assert;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;
 
public class tstTriangle {
 
    @DataProvider(name = "checkTriangleDataProvider")
    public Object[][] createCheckTriangleData() {
        return new Object[][] { 
        	/*Correct isosceles triangle*/
                { new Double(5.55), new Double(5.55), new Double(2.55), new Boolean(true) },
               /* Correct ordinary triangle*/
                { new Double(6), new Double(5), new Double(8), new Boolean(true) },
                /*Correct equilateral triangle*/
                { new Double(5.55), new Double(5.55), new Double(5.55), new Boolean(true) },
                /*Exponential numbers*/
                { new Double(1e+2), new Double(1e+2), new Double(1e+2), new Boolean(true) },
                
               /* Length of the side < 0*/
                { new Double(6), new Double(3), new Double(-2), new Boolean(false) },
                { new Double(-3), new Double(3), new Double(3), new Boolean(false) },
                { new Double(3), new Double(-3), new Double(3), new Boolean(false) },
                
                /*Length of the side = 0 */
                { new Double(3), new Double(0), new Double(3), new Boolean(false) },
                { new Double(4), new Double(3), new Double(0), new Boolean(false) },
                { new Double(0), new Double(3), new Double(3), new Boolean(false) },
                
                /*Sum of two sides is less the third side*/
                { new Double(5), new Double(2.5), new Double(1.5), new Boolean(false) },
                /*Sum of two sides is = the third side*/
                { new Double(1), new Double(2), new Double(3), new Boolean(false) }, };
    }
     
    @DataProvider(name = "detectTriangleDataProvider")
    public Object[][] createDetectTriangleData() {
        return new Object[][] { 
        	/*Correct isosceles triangle*/
            { new Double(5.55), new Double(5.55), new Double(2.55), new Integer(2) },
            /* Correct ordinary triangle*/
            { new Double(5), new Double(3), new Double(4), new Integer(4) },
            /*Correct equilateral triangle*/
            { new Double(5.55), new Double(5.55), new Double(5.55), new Integer(1) },
            /*Correct rectangular triangle*/
            { new Double(3), new Double(4), new Double(5), new Integer(8) },      
            /*Exponential numbers*/ 
            { new Double(1e+2), new Double(1e+2), new Double(1e+2), new Integer(1) },
        };
    }
  
    @DataProvider(name = "getSquareDataProvider")
    public Object[][] createGetSquareData() {
    	return new Object[][] { 
    		/*Correct isosceles triangle*/
    		{ new Double(5.55), new Double(5.55), new Double(2.55), new Double(6.887) },
    		/* Correct ordinary triangle*/
    		{ new Double(6), new Double(5), new Double(8), new Double(14.98) },
    		/*Correct equilateral triangle*/
    		{ new Double(5.55), new Double(5.55), new Double(5.55), new Double(13.34) },
    		/*Correct rectangular triangle*/
    		{ new Double(3), new Double(4), new Double(5), new Double(6) },
    		/*Exponential numbers*/ 
    		{ new Double(1e+2), new Double(1e+2), new Double(1e+2), new Double(4330.13) },
    	};
    }
    
    @DataProvider(name = "MessageDataProvider")
    public Object[][] createMessageData() {
        return new Object[][] { 
           
                { new Double(0), new Double(2), new Double(3), new String("a<=0") },
                { new Double(-5), new Double(2), new Double(3), new String("a<=0") },
              
                { new Double(2), new Double(0), new Double(3), new String("b<=0") },
                { new Double(3), new Double(-7), new Double(3), new String("b<=0") },
                
                { new Double(1), new Double(2), new Double(0), new String("c<=0") },
                { new Double(1), new Double(2), new Double(-5), new String("c<=0") },
                
                { new Double(2), new Double(2), new Double(5), new String("a+b<=c") },
                { new Double(2), new Double(2), new Double(4), new String("a+b<=c") },
                
                { new Double(2), new Double(7), new Double(2), new String("a+c<=b") },
                { new Double(2), new Double(9), new Double(7), new String("a+c<=b") },
                
                { new Double(6), new Double(2), new Double(4), new String("b+c<=a") },
                { new Double(7), new Double(2), new Double(4), new String("b+c<=a") },
                
        };
    }
     
    @Test(dataProvider = "checkTriangleDataProvider")
    public void tstCheckTriangle(Double a, Double b, Double c, Boolean d) {
        Triangle triangle = new Triangle(a, b, c);
        Assert.assertEquals((Boolean) triangle.checkTriangle(), d);
    }
     
    @Test(dataProvider = "detectTriangleDataProvider")
    public void tstDetectTriangle(Double a, Double b, Double c, Integer d) {
        Triangle triangle = new Triangle(a, b, c);
        Assert.assertEquals((Integer) triangle.detectTriangle(), d);
 
    }
 
    @Test(dataProvider = "getSquareDataProvider")
    public void tstGetSquare(Double a, Double b, Double c, Double square) {
        Triangle triangle = new Triangle(a, b, c);
        Assert.assertEquals(triangle.getSquare(), square, 0.01);
    }
 
    @Test(dataProvider = "MessageDataProvider")
    public void tstMessage(Double a, Double b, Double c, String message) {
        Triangle triangle = new Triangle(a, b, c);
        triangle.checkTriangle();
        Assert.assertEquals(triangle.getMessage(), message);
    }
}
