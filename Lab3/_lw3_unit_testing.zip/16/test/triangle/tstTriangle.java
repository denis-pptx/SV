
import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.testng.Assert;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;
import org.testng.collections.Lists;

public class tstTriangle {
	Triangle tr;

	@DataProvider(name = "triangleDataProvider")
	public static Object[][] createTriangle() {
		return new Object[][] { { true, 1, new ArrayList<Double>(Arrays.asList(1.0, 1.0, 1.0)) },
				{ true, 2, new ArrayList<Double>(Arrays.asList(2.0, 1.5, 1.5)) },
				{ true, 2, new ArrayList<Double>(Arrays.asList(1.5, 2.0, 1.5)) },
				{ true, 2, new ArrayList<Double>(Arrays.asList(1.5, 1.5, 2.0)) },
				{ true, 4, new ArrayList<Double>(Arrays.asList(3.0, 1.5, 2.0)) },
				{ true, 8, new ArrayList<Double>(Arrays.asList(2.0, 1.5, 2.5)) },
				{ true, 2,
						new ArrayList<Double>(
								Arrays.asList(Double.MAX_VALUE, Double.MAX_VALUE, 1.0)) },
				{ true, 2,
						new ArrayList<Double>(
								Arrays.asList(Double.MAX_VALUE, 1.0, Double.MAX_VALUE)) },
				{ true, 2, new ArrayList<Double>(
						Arrays.asList(1.0, Double.MAX_VALUE, Double.MAX_VALUE)) }

		};
	}

	@DataProvider(name = "notExistingTriangleDataProvider")
	public static Object[][] doesNotExistTrianfle() {
		return new Object[][] { { false, new ArrayList<Double>(Arrays.asList(5.0, 2.0, 1.0)) },
				{ false, new ArrayList<Double>(Arrays.asList(2.0, 5.0, 1.0)) },
				{ false, new ArrayList<Double>(Arrays.asList(2.0, 1.0, 5.0)) },
				{ false, new ArrayList<Double>(Arrays.asList(2.0, 2.0, 4.0)) },
				{ false, new ArrayList<Double>(Arrays.asList(2.0, 4.0, 2.0)) },
				{ false, new ArrayList<Double>(Arrays.asList(4.0, 2.0, 2.0)) },
				{ false, new ArrayList<Double>(Arrays.asList(-1.0, 2.0, 2.0)) },
				{ false, new ArrayList<Double>(Arrays.asList(2.0, -1.0, 2.0)) },
				{ false, new ArrayList<Double>(Arrays.asList(2.0, 2.0, -1.0)) },
				{ false, new ArrayList<Double>(Arrays.asList(-1.0, -1.0, 3.0)) },
				{ false, new ArrayList<Double>(Arrays.asList(-1.0, 3.0, -1.0)) },
				{ false, new ArrayList<Double>(Arrays.asList(0.0, 2.0, 2.0)) },
				{ false, new ArrayList<Double>(Arrays.asList(2.0, 0.0, 2.0)) },
				{ false, new ArrayList<Double>(Arrays.asList(2.0, 2.0, 0.0)) },
				{ false, new ArrayList<Double>(Arrays.asList(0.0, 0.0, 0.0)) },
				{ false, new ArrayList<Double>(Arrays.asList(1.5, 1.5)) },
				{ false, new ArrayList<Double>(Arrays.asList(1.5)) },
				{ false, new ArrayList<Double>(Arrays.asList(1.5, 1.5, 2.0, 2.0)) },

		};
	}
		
	/**
	 * Checks if the message field is initialized with "";
	 * 
	 * @param exist
	 * @param sort
	 * @param parameters
	 */
	@Test(enabled = true, dataProvider = "triangleDataProvider")
	public void tstConstructor(boolean exist, int sort, ArrayList<Double> parameters) {
		double a = (Double) parameters.get(0);
		double b = (Double) parameters.get(1);
		double c = (Double) parameters.get(2);

		Triangle tr = new Triangle(a, b, c);

		Field msg;
		String fieldValue = "test failed";
		try {
			msg = Triangle.class.getDeclaredField("message");
			msg.setAccessible(true);
			fieldValue = (String) msg.get(tr);
		} catch (NoSuchFieldException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SecurityException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IllegalArgumentException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IllegalAccessException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		Assert.assertEquals(fieldValue, "");
	}

	@Test(groups = "mainTest", dataProvider = "triangleDataProvider")
	public void tstDetectTriangle(boolean isExist, int sort, ArrayList<Double> parameters) {
		double a = (Double) parameters.get(0);
		double b = (Double) parameters.get(1);
		double c = (Double) parameters.get(2);

		Triangle tr = new Triangle(a, b, c);

		int actualSort = tr.detectTriangle();
		Assert.assertEquals(actualSort, sort);
	}

	/*
	 * Needs to create user exception
	 */
	@Test(enabled = false, groups = "mainTest", dataProvider = "notExistingTriangleDataProvider", expectedExceptions = Exception.class)

	public void tstDetectTriangle(boolean isExist, ArrayList<Double> parameters) {
		double a = (Double) parameters.get(0);
		double b = (Double) parameters.get(1);
		double c = (Double) parameters.get(2);

		Triangle tr = new Triangle(a, b, c);

		int actualSort = tr.detectTriangle();
	}

	
	@Test(groups = "mainTest", dataProvider = "triangleDataProvider" )
	public void tstCheckTriangle(boolean isExist, int sort, ArrayList<Double> parameters) {
		double a = (Double) parameters.get(0);
		double b = (Double) parameters.get(1);
		double c = (Double) parameters.get(2);

		Triangle tr = new Triangle(a, b, c);

		boolean checked = tr.checkTriangle();
		Assert.assertEquals(checked, isExist);
	}
	
	@Test(groups = "mainTest", dataProvider = "notExistingTriangleDataProvider" )
	public void tstCheckTriangle(boolean isExist,  ArrayList<Double> parameters) {
		double a = (Double) parameters.get(0);
		double b = (Double) parameters.get(1);
		double c = (Double) parameters.get(2);

		Triangle tr = new Triangle(a, b, c);

		boolean checked = tr.checkTriangle();
		Assert.assertEquals(checked, isExist);
	}
	
}
