
import org.testng.Assert;
import org.testng.annotations.*;


public class tstTriangle {
	
	private Triangle triangle;
	final int TR_EQUILATERAL = 1; // ��������������
	final int TR_ISOSCELES = 2;   // ��������������
	final int TR_ORDYNARY = 4;    // �������
	final int TR_RECTANGULAR = 8; // �������������
	
	@DataProvider
	public Object[][] squareRightSidesData() {
	return new Object[][] {
	{ 2, 6, 5, 0 },
	};
	}
	
	@DataProvider
	public Object[][] squareOneSideZero() {
	return new Object[][] {
	{ 0, 6, 5, Double.NaN },
	{ 2, 0, 5, Double.NaN },
	};
	}
	
	@DataProvider
	public Object[][] rightSidesDataInt() {
	return new Object[][] {
	{ 2, 6, 5 },
	};
	}
	
	@DataProvider
	public Object[][] rightSidesDataDouble() {
	return new Object[][] {
	{ 0.2, 0.6, 0.5 },
	};
	}
	
	@DataProvider
	public Object[][] rectangularData() {
	return new Object[][] {
	{ 8, 6, 10 },
	{ 6, 10, 8 },
	{ 10, 8, 6 },
	};
	}
	
	@DataProvider
	public Object[][] isoscelesSidesData() {
	return new Object[][] {
	{ 2, 1, 2 },
	{ 2, 2, 1 },
	{ 1, 2, 2 }
	};
	}
	
	@DataProvider
	public Object[][] equilateralSidesData() {
	return new Object[][] {
	{ 1, 1, 1 }
	};
	}
	
	@DataProvider
	public Object[][] zeroSidesData() {
	return new Object[][] {
	{ 0, 1, 1 },
	{ 1, 0, 1 },
	{ 1, 1, 0 }
	};
	}
	
	@DataProvider
	public Object[][] allSidesZeroData() {
	return new Object[][] {
	{ 0, 0, 0 }
	};
	}
	
	@DataProvider
	public Object[][] twoSidesSummEqualsThirdData() {
	return new Object[][] {
	{ 1, 2, 3 },
	{ 1000, 200, 800},
	{ 50000, 100000, 50000 }
	};
	}
	
	@DataProvider
	public Object[][] twoSidesSummLessThanThirdData() {
	return new Object[][] {
	{ 1, 2, 3 },
	{ 1000, 200, 800},
	{ 50000, 100000, 50000 }
	};
	}
	
	@DataProvider
	public Object[][] NaNSideData() {
	return new Object[][] {
	{ Double.NaN, 2, 3 },
	{ 1000, Double.NaN, 800},
	{ 50000, 100000, Double.NaN }
	};
	}
	
	@DataProvider
	public Object[][] negativeSidesData() {
	return new Object[][] {
	{ -100, 400, 500 },
	{ 1, -4, 5},
	{ 50000, 100000, -50000 }
	};
	}
	
	@DataProvider
	public Object[][] maxDoubleSidesData() {
	return new Object[][] {
		{ Double.MAX_VALUE, 2, 3 },
		{ 1000, Double.MAX_VALUE, 800},
		{ 50000, 100000, Double.MAX_VALUE }
		};
		}
	
	@DataProvider
	public Object[][] minDoubleSidesData() {
	return new Object[][] {
		{ Double.MIN_VALUE, 2, 2 },
		{ 1000, Double.MIN_VALUE, 1000},
		{ 50000, 50000, Double.MIN_VALUE }
		};
		}
	
	@DataProvider
	public Object[][] infinitySidesData() {
	return new Object[][] {
	{ Double.POSITIVE_INFINITY, 400, 500 },
	{ 1, Double.POSITIVE_INFINITY, 5},
	{ 50000, 100000, Double.POSITIVE_INFINITY },
	{ Double.NEGATIVE_INFINITY, 400, 500 },
	{ 1, Double.NEGATIVE_INFINITY, 5},
	{ 50000, 100000, Double.NEGATIVE_INFINITY }
	};
	}

	@Test(groups = { "checkTriangle" }, dataProvider = "rightSidesDataInt")
	public void checkTriangle_rightSidesInt(double a, double b, double c) {
		triangle = new Triangle(a, b, c);
		Assert.assertTrue(triangle.checkTriangle());
	}

	@Test(groups = { "checkTriangle" }, dataProvider = "rightSidesDataDouble")
	public void checkTriangle_rightSidesDouble(double a, double b, double c) {
		triangle = new Triangle(a, b, c);
		Assert.assertTrue(triangle.checkTriangle());
	}

	@Test(groups = { "checkTriangle" }, dataProvider = "zeroSidesData")
	public void checkTriangle_zeroSide(double a, double b, double c) {
		triangle = new Triangle(a, b, c);
		Assert.assertFalse(triangle.checkTriangle());
	}

	@Test(groups = { "checkTriangle" }, dataProvider = "allSidesZeroData")
	public void checkTriangle_allZeroSides(double a, double b, double c) {
		triangle = new Triangle(a, b, c);
		Assert.assertFalse(triangle.checkTriangle());
	}

	@Test(groups = { "checkTriangle" }, dataProvider = "negativeSidesData")
	public void checkTriangle_negativeSide(double a, double b, double c) {
		triangle = new Triangle(a, b, c);
		Assert.assertFalse(triangle.checkTriangle());
	}

	@Test(groups = { "checkTriangle" }, dataProvider = "maxDoubleSidesData")
	public void checkTriangle_maxDoubleSide(double a, double b, double c) {
		triangle = new Triangle(a, b, c);
		Assert.assertFalse(triangle.checkTriangle());
	}

	@Test(groups = { "checkTriangle" }, dataProvider = "minDoubleSidesData")
	public void checkTriangle_minDoubleSide(double a, double b, double c) {
		triangle = new Triangle(a, b, c);
		Assert.assertFalse(triangle.checkTriangle());
	}

	@Test(groups = { "checkTriangle" }, dataProvider = "NaNSideData")
	public void checkTriangle_NaNSide(double a, double b, double c) {
		triangle = new Triangle(a, b, c);
		Assert.assertFalse(triangle.checkTriangle());
	}

	@Test(groups = { "checkTriangle" }, dataProvider = "infinitySidesData")
	public void checkTriangle_infinity(double a, double b, double c) {
		triangle = new Triangle(a, b, c);
		Assert.assertFalse(triangle.checkTriangle());
	}

	@Test(groups = { "checkTriangle" }, dataProvider = "twoSidesSummEqualsThirdData")
	public void checkTriangle_twoSidesSumEqualsThird(double a, double b, double c) {
		triangle = new Triangle(a, b, c);
		Assert.assertFalse(triangle.checkTriangle());
	}

	@Test(groups = { "checkTriangle" }, dataProvider = "twoSidesSummLessThanThirdData")
	public void checkTriangle_twoSidesSumLessThanThird(double a, double b, double c) {
		triangle = new Triangle(a, b, c);
		Assert.assertFalse(triangle.checkTriangle());
	}

	@Test(groups = { "detectTriangle" }, dataProvider = "rightSidesDataInt")
	public void detectTriangle_rightSidesInt(double a, double b, double c) {
		triangle = new Triangle(a, b, c);
		Assert.assertEquals(triangle.detectTriangle(), TR_ORDYNARY, 0.01);
	}

	@Test(groups = { "detectTriangle" }, dataProvider = "detectTriangle")
	public void detectTriangle_rightSidesDouble(double a, double b, double c) {
		triangle = new Triangle(a, b, c);
		Assert.assertEquals(triangle.detectTriangle(), TR_ORDYNARY, 0.01);
	}

	@Test(groups = { "detectTriangle" }, dataProvider = "isoscelesSidesData")
	public void detectTriangle_isosceles(double a, double b, double c) {
		triangle = new Triangle(a, b, c);
		Assert.assertEquals(triangle.detectTriangle(), TR_ISOSCELES, 0.01);
	}

	@Test(groups = { "detectTriangle" }, dataProvider = "equilateralSidesData")
	public void detectTriangle_equilateral(double a, double b, double c) {
		triangle = new Triangle(a, b, c);
		Assert.assertEquals(triangle.detectTriangle(), TR_EQUILATERAL, 0.01);
	}

	@Test(groups = { "detectTriangle" }, dataProvider = "equilateralSidesData")
	public void detectTriangle_rectangular(double a, double b, double c) {
		triangle = new Triangle(a, b, c);
		Assert.assertEquals(triangle.detectTriangle(), TR_RECTANGULAR, 0.01);
	}

	@Test(groups = { "detectTriangle" }, dataProvider = "zeroSidesData")
	public void detectTriangle_zeroSide(double a, double b, double c) {
		triangle = new Triangle(a, b, c);
		int result = triangle.detectTriangle();
		Assert.assertTrue((result != TR_ORDYNARY) && (result != TR_EQUILATERAL) && (result != TR_RECTANGULAR)
				&& (result != TR_ISOSCELES));

	}

	@Test(groups = { "detectTriangle" }, dataProvider = "allSidesZeroData")
	public void detectTriangle_allZeroSides(double a, double b, double c) {
		triangle = new Triangle(a, b, c);
		int result = triangle.detectTriangle();
		Assert.assertTrue((result != TR_ORDYNARY) && (result != TR_EQUILATERAL) && (result != TR_RECTANGULAR)
				&& (result != TR_ISOSCELES));
	}

	@Test(groups = { "detectTriangle" }, dataProvider = "maxDoubleSidesData")
	public void detectTriangle_maxDoubleSide(double a, double b, double c) {
		triangle = new Triangle(a, b, c);
		int result = triangle.detectTriangle();
		// Assert.fail();
		Assert.assertFalse((result != TR_ORDYNARY) && (result != TR_EQUILATERAL) && (result != TR_RECTANGULAR)
				&& (result != TR_ISOSCELES));
	}

	@Test(groups = { "detectTriangle" }, dataProvider = "minDoubleSidesData")
	public void detectTriangle_minDoubleSide(double a, double b, double c) {
		triangle = new Triangle(a, b, c);
		int result = triangle.detectTriangle();
		Assert.assertTrue((result != TR_ORDYNARY) && (result != TR_EQUILATERAL) && (result != TR_RECTANGULAR)
				&& (result != TR_ISOSCELES));
	}

	@Test(groups = { "detectTriangle" }, dataProvider = "negativeSidesData")
	public void detectTriangle_negativeSide(double a, double b, double c) {
		triangle = new Triangle(a, b, c);
		int result = triangle.detectTriangle();
		Assert.assertTrue((result != TR_ORDYNARY) && (result != TR_EQUILATERAL) && (result != TR_RECTANGULAR)
				&& (result != TR_ISOSCELES));
	}

	@Test(groups = { "detectTriangle" }, dataProvider = "NaNSideData")
	public void detectTriangle_NaNSide(double a, double b, double c) {
		triangle = new Triangle(a, b, c);
		int result = triangle.detectTriangle();
		Assert.assertTrue((result != TR_ORDYNARY) && (result != TR_EQUILATERAL) && (result != TR_RECTANGULAR)
				&& (result != TR_ISOSCELES));
	}

	@Test(groups = { "detectTriangle" }, dataProvider = "infinitySidesData")
	public void detectTriangle_infinity(double a, double b, double c) {
		triangle = new Triangle(a, b, c);
		int result = triangle.detectTriangle();
		Assert.assertTrue((result != TR_ORDYNARY) && (result != TR_EQUILATERAL) && (result != TR_RECTANGULAR)
				&& (result != TR_ISOSCELES));
	}

	@Test(groups = { "getSquare" }, dataProvider = "squareRightSidesData")
	public void getSquare_rightSides(double a, double b, double c, double square) {
		triangle = new Triangle(a, b, c);
		Assert.assertEquals(triangle.getSquare(), square);
	}

	@Test(groups = { "getSquare" }, dataProvider = "squareOneSideZero")
	public void getSquare_squareOneZeroSide(double a, double b, double c, double square) {
		triangle = new Triangle(a, b, c);
		Assert.assertEquals(triangle.getSquare(), square);
	}

}
