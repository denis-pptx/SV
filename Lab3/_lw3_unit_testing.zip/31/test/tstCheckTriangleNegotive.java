
import org.testng.annotations.Test;

import pr.chyrko_anton.triangle.Triangle;

import org.testng.Assert;
import org.testng.annotations.DataProvider;

public class tstCheckTriangleNegotive {
  @Test(dataProvider = "dp")
  public void f(Double a, Double b, Double c, String EXP) {
	  Triangle triangle = new Triangle(a, b, c);
	  triangle.checkTriangle();
	  Assert.assertEquals(triangle.getMessage(), EXP);
  }

  @DataProvider
  public Object[][] dp() {
    return new Object[][] {
      new Object[] { -2.0, 3.0, 4.0, "a<=0"},
      new Object[] { 2.0, -3.0, 4.0, "b<=0"},
      new Object[] { 2.0, 3.0, -4.0, "c<=0"},
      new Object[] { 2.0, 3.0, 5.0, "a+b<=c"},
      new Object[] { 2.0, 5.0, 3.0, "a+c<=b"},
      new Object[] { 5.0, 3.0, 2.0, "b+c<=a"},
    };
  }
}
