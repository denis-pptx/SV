
import org.testng.annotations.Test;

import pr.chyrko_anton.triangle.Triangle;

import org.testng.Assert;
import org.testng.annotations.DataProvider;

public class tstDetectTriangleNegotive {
	
	private String[] binary = {
			"0000","0001","0010","0011","0100","0101","0110","0111",
			"1000","1001","1010","1011","1100","1101","1110","1111"
	};	
	
  @Test(dataProvider = "TR_ORDYNARY")
  public void f1(Double a, Double b, Double c, String EXP) {
	  Triangle triangle = new Triangle(a, b, c);
	  Assert.assertFalse(triangle.checkTriangle());
	  Assert.assertEquals(binary[triangle.detectTriangle()], EXP);	  
  }
  
  //----------------DATAPROVIDERS----------------------------------------------  

  @DataProvider(name = "TR_ORDYNARY")
  public Object[][] dp1() {
    return new Object[][] {
    	// not exist		0000
      new Object[] {2.0, 3.0, 5.0, "0000" },
      new Object[] {2.0, 5.0, 3.0, "0000" },
      new Object[] {3.0, 2.0, 5.0, "0000" },
      new Object[] {3.0, 5.0, 2.0, "0000" },
      new Object[] {5.0, 2.0, 3.0, "0000" },
      new Object[] {5.0, 3.0, 2.0, "0000" },
      new Object[] {0.0, 0.0, 3.0 , "0000"},
      new Object[] {0.0, 0.0, 0.0 , "0000"},
      new Object[] {0.0, 3.0, 3.0 , "0000"},
      new Object[] {-3.0, -2.0, -4.0 , "0000"},
    };
  }  
}
