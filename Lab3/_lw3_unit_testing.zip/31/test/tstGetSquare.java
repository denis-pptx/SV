
import org.testng.annotations.Test;

import pr.chyrko_anton.triangle.Triangle;

import org.testng.Assert;
import org.testng.annotations.DataProvider;

public class tstGetSquare {
	@Test(dataProvider = "CorrectValues")
	  public void f1(Double a, Double b, Double c) {	  
		  Triangle triangle = new Triangle(a, b, c);
		  Double p = (a+b+c)/2;
		  Double square = Math.sqrt(p*(p-a)*(p-b)*(p-c));
		  Assert.assertEquals(triangle.getSquare(), square);	  
	  }  

	 @Test(dataProvider = "IncorrectValues")
	  public void f2(Double a, Double b, Double c) {	  
		  Triangle triangle = new Triangle(a, b, c);	 
		  Assert.assertTrue(Double.isNaN(triangle.getSquare()));		  
	 }	  
	  
	  @Test(dataProvider = "ZeroValues")
	  public void f3(Double a, Double b, Double c){
		  Triangle triangle = new Triangle(a, b, c);
		  Assert.assertTrue(Double.isNaN(triangle.getSquare()));
	  }
	  
	  @Test(dataProvider = "NegativeValues")
	  public void f4(Double a, Double b, Double c){
		  Triangle triangle = new Triangle(a, b, c);	
		  Assert.assertTrue(triangle.checkTriangle());
		  Double p = (a+b+c)/2;
		  Double square = Math.sqrt(p*(p-a)*(p-b)*(p-c));
		  Assert.assertNotEquals(triangle.getSquare(), square);
	  }
	  
	  @DataProvider(name = "NegativeValues")
	  public Object[][] dp4() {
	    return new Object[][] {
	      new Object[] { -2.0, 3.0, 4.0 },
	      new Object[] { 2.0, -3.0, 4.0 },
	      new Object[] { 2.0, 3.0, -4.0 },
	      new Object[] { -2.0, -3.0, 4.0 },
	      new Object[] { -2.0, 3.0, -4.0 },
	      new Object[] { 2.0, -3.0, -4.0 },
	      new Object[] { -2.0, -3.0, -4.0 },      
	    };
	  }

	  @DataProvider(name = "CorrectValues")
	  public Object[][] dp1() {
	    return new Object[][] {
	      new Object[] { 2.0, 3.0, 4.0 },
	      new Object[] { 0.0002, 0.0003, 0.0004 },
	    };
	  }
	  
	  @DataProvider(name = "IncorrectValues")
	  public Object[][] dp2() {
	    return new Object[][] {
	      new Object[] { 2.0, 3.0, 6.0 },
	      new Object[] { 2.0, 6.0, 3.0 },
	      new Object[] { 3.0, 2.0, 6.0 },
	      new Object[] { 3.0, 6.0, 2.0 },
	      new Object[] { 6.0, 2.0, 3.0 },
	      new Object[] { 6.0, 3.0, 2.0 },
	    };
	  }
	  
	  @DataProvider(name = "ZeroValues")
	  public Object[][] dp3() {
	    return new Object[][] {
	      new Object[] { 0.0, 3.0, 4.0 },
	      new Object[] { 2.0, 0.0, 4.0 },
	      new Object[] { 2.0, 3.0, 0.0 },
	      new Object[] { 0.0, 0.0, 4.0 },
	      new Object[] { 2.0, 0.0, 0.0 },
	      new Object[] { 0.0, 3.0, 0.0 },
	      new Object[] { 0.0, 0.0, 0.0 },
	    };
	  }
}
