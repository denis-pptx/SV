
import org.testng.annotations.Test;
import pr.chyrko_anton.triangle.Triangle;
import org.testng.Assert;
import org.testng.annotations.DataProvider;

public class tstCheckTrianglePositive {
  @Test(dataProvider = "dp")
  public void f(Double a, Double b, Double c) {
	  Triangle triangle = new Triangle(a, b, c);
	  Assert.assertTrue(triangle.checkTriangle());	  
  }

  @DataProvider
  public Object[][] dp() {
    return new Object[][] {
      new Object[] { 2.0, 3.0, 4.0 },     
      new Object[] { 0.0002, 0.0003, 0.0004 },
      new Object[] { Double.MAX_VALUE, Double.MAX_VALUE, Double.MAX_VALUE },
    };
  }
}
