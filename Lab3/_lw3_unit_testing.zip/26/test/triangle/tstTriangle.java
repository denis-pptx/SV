
import org.junit.Assert;
import org.junit.Test;

public class tstTriangle {

	@Test
	public void createUsualTriangleWithCorrectValues() {
		createAndVerifyTriangle(8, 7, 3);
	}

	@Test
	public void c�reateEquilateralTrangleWithCorrectValues() {
		createAndVerifyTriangle(4, 4, 5);
	}

	@Test
	public void createIsoscelesTriangleWithCorrectValues() {
		createAndVerifyTriangle(8, 8, 8);
	}

	@Test
	public void createRightTriangleWithCorrectValues() {
		createAndVerifyTriangle(3, 4, 5);
	}

	private void createAndVerifyTriangle(double a, double b, double c) {
		Triangle triangle = new Triangle(a, b, c);
		Assert.assertNotNull("Triagle should not be null", triangle);
	}

	@Test
	public void createTriangleWithNegativeValues() {
		new Triangle(-1, -1, -1);
	}

	@Test
	public void createTriangleWithZeroValues() {
		new Triangle(0, 0, -1);
	}

	@Test
	public void createTriagleWithSideCEqualsSumSideAandSideB() {
		new Triangle(1, 1, 2);
	}

	@Test
	public void createTriangeWithSideCBiggerSumSideAandSideB() {
		new Triangle(1, 2, 9);
	}

	@Test
	public void createTriangleWithValuesMoreThanDoubleMaxValues() {
		new Triangle(Double.MAX_VALUE * Double.MAX_VALUE, Double.MAX_VALUE * Double.MAX_VALUE,
				Double.MAX_VALUE * Double.MAX_VALUE);
	}

	@Test
	public void messageShouldBeEmptyAfterCreateTriangle() {
		Triangle triangle = new Triangle(2, 4, 8);
		Assert.assertEquals("Message should  be empty string", "", triangle.getMessage());
	}

	@Test
	public void triangleWithCorrectSides() {
		checkTriangle(6, 8, 12, true, "");
	}

	@Test
	public void triangleWithIncorrectSideA() {
		checkTriangle(0, 8, 12, false, "a<=0");
	}

	@Test
	public void triangleWithIncorrectSideB() {
		checkTriangle(7, 0, 12, false, "b<=0");
	}

	@Test
	public void triangleWithIncorrectSideC() {
		checkTriangle(7, 7, 0, false, "�<=0");
	}

	@Test
	public void triangleWithSideCbiggerOrEqualsSumAandB() {
		checkTriangle(1, 2, 3, false, "a+b<=c");

	}

	@Test
	public void triangleWithSideBEqualsOrBiggerSumBandC() {
		checkTriangle(1, 3, 2, false, "a+c<=b");
	}

	@Test
	public void triangleWithSideAEqualsOrBiggerSumBandC() {
		checkTriangle(3, 2, 1, false, "b+c<=a");
	}

	private void checkTriangle(int a, int b, int c, boolean isValidTrangle, String exppectedMessage) {
		Triangle triangle = new Triangle(a, b, c);
		Assert.assertEquals(isValidTrangle, triangle.checkTriangle());
		Assert.assertEquals(exppectedMessage, triangle.getMessage());
	}

	private void detectTypeTriangle(double a, double b, double c, int expectedResult) {
		Triangle triangle = new Triangle(a, b, c);
		Assert.assertEquals(expectedResult, triangle.detectTriangle());
	}

	@Test
	public void triangleIsRightShouldBeValid() {
		detectTypeTriangle(3, 4, 5, 8);
	}

	@Test
	public void triangleIsEquilateralShouldBeValid() {
		detectTypeTriangle(5, 5, 5, 3);
	}

	@Test
	public void triangleIsIsoscelesShouldBeValid() {
		detectTypeTriangle(4, 4, 5, 2);
	}

	@Test
	public void triangleIsUsualShouldBeValid() {
		detectTypeTriangle(5, 6, 8, 4);
	}

	@Test
	public void triangleSquareShouldBeValid() {
		Triangle triangle = new Triangle(5, 3, 4);
		Assert.assertEquals(6, triangle.getSquare(), 0.01);
	}

}
