
import java.util.ArrayList;
import java.util.Arrays;

import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

public class NegativeTestTriangle {
	private Triangle triangle;

	@AfterMethod
	public void afterMethod() {
		triangle = null;
	}

	@DataProvider(name = "TriangleNotExistValues")
	public Object[][] dataTriangleNotExist() {
		return new Object[][] { 
				{ 0, new ArrayList<Double>(Arrays.asList(0.0, 1.0, 2.0)) },
				{ 0, new ArrayList<Double>(Arrays.asList(1.0, 0.0, 2.0)) },
				{ 0, new ArrayList<Double>(Arrays.asList(1.0, 2.0, 0.0)) },
				{ 0, new ArrayList<Double>(Arrays.asList(2.0, 2.0, 4.0)) },
				{ 0, new ArrayList<Double>(Arrays.asList(2.0, 4.0, 2.0)) },
				{ 0, new ArrayList<Double>(Arrays.asList(4.0, 2.0, 2.0)) },
				{ 0, new ArrayList<Double>(Arrays.asList(-2.0, 2.0, 3.0)) },
				{ 0, new ArrayList<Double>(Arrays.asList(2.0, -2.0, 3.0)) },
				{ 0, new ArrayList<Double>(Arrays.asList(-3.0, -3.0, -3.0)) },
				{ 0, new ArrayList<Double>(Arrays.asList(Double.NEGATIVE_INFINITY, Double.NEGATIVE_INFINITY,Double.NEGATIVE_INFINITY)) },
				{ 0, new ArrayList<Double>(Arrays.asList(Double.POSITIVE_INFINITY, Double.POSITIVE_INFINITY,Double.POSITIVE_INFINITY)) },
				{ 0, new ArrayList<Double>(Arrays.asList(Double.NaN, Double.NaN,Double.NaN)) },
		};
	}

	@Test(dataProvider = "TriangleNotExistValues")
	public void tst_checkTriangle(int res,ArrayList<Double> side) {
		triangle = new Triangle(side.get(0),side.get(1),side.get(2));
		Assert.assertFalse(triangle.checkTriangle());
	}
			
	@Test(dataProvider = "TriangleNotExistValues")
	public void tst_detectTriangle(int res, ArrayList<Double> side) {
		triangle = new Triangle(side.get(0), side.get(1), side.get(2));
		Assert.assertEquals(triangle.detectTriangle(), res);
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
				
}
