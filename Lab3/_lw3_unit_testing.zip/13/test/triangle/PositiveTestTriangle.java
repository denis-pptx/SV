
import java.util.ArrayList;
import java.util.Arrays;

import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

public class PositiveTestTriangle {
	private Triangle triangle;
	@AfterMethod
	public void afterMethod() {
		triangle = null;
	}
	@DataProvider(name = "SmokeTestData")
	public Object[][] createSmokeTestData() {
		return new Object[][] { 
				{ 3, new ArrayList<Double>(Arrays.asList(3.0, 3.0, 3.0)) },
				{ 2, new ArrayList<Double>(Arrays.asList(2.0, 2.0, 3.0)) },
				{ 2, new ArrayList<Double>(Arrays.asList(2.0, 3.0, 2.0)) },
				{ 2, new ArrayList<Double>(Arrays.asList(3.0, 2.0, 2.0)) },
				{ 8, new ArrayList<Double>(Arrays.asList(3.0, 4.0, 5.0)) },
				{ 8, new ArrayList<Double>(Arrays.asList(3.0, 5.0, 4.0)) },
				{ 8, new ArrayList<Double>(Arrays.asList(4.0, 3.0, 5.0)) },
				{ 8, new ArrayList<Double>(Arrays.asList(5.0, 4.0, 3.0)) },
				{ 8, new ArrayList<Double>(Arrays.asList(5.0, 4.0, 3.0)) },
				{ 4, new ArrayList<Double>(Arrays.asList(3.0, 2.0, 4.0)) },
				{ 3, new ArrayList<Double>(Arrays.asList(Double.MAX_VALUE, Double.MAX_VALUE, Double.MAX_VALUE)) },
		};
	}
	
	@Test(dataProvider = "SmokeTestData")
	public void tst_checkTriangle(int res,ArrayList<Double> side) {
		triangle = new Triangle(side.get(0), side.get(1), side.get(2));
		Assert.assertTrue(triangle.checkTriangle());
	}

	@Test(dataProvider = "SmokeTestData")
	public void tst_detectTriangle(int res, ArrayList<Double> side) {
		triangle = new Triangle(side.get(0), side.get(1), side.get(2));
		Assert.assertEquals(triangle.detectTriangle(),res);
	}
	
	
}
