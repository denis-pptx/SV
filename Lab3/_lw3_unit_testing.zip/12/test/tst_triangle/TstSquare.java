
import java.util.ArrayList;
import java.util.Arrays;

import org.testng.Assert;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import triangle.Triangle;

public class TstSquare {
	@DataProvider(name="dataProviderTriangle")
	public Object [][] createDataTriangle(){
		double A=2;//sides of
		double B=2;//of
		double C=3;//triangle
		return new Object[][]
			{
				{"Just Triangle", new ArrayList<Double>(Arrays.asList(A, B , C))},				
			};		
	}
  @Test(dataProvider = "dataProviderTriangle")
  public void testRectangularTriangle(String defenition, ArrayList<Double> parameters) {
	  
	  double side_a=(Double)(parameters.get(0));
	  double side_b=(Double)(parameters.get(1));
	  double side_c=(Double)(parameters.get(2));
	  double cos_a_b=(side_b*side_b +side_a*side_a-side_c*side_c)/2*side_a*side_b;//incomplited :(
	  double sin_a_b=Math.sqrt(1-cos_a_b*cos_a_b);
	  Triangle triangleToTest = new Triangle(side_a, side_b, side_c);
	  Assert.assertTrue(sin_a_b*side_a*side_b/2 ==triangleToTest.getSquare());
	  
  }
}
