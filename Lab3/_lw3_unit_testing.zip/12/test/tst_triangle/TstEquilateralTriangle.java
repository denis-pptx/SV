

import java.util.ArrayList;
import java.util.Arrays;

import org.testng.Assert;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import triangle.Triangle;

public class TstEquilateralTriangle {
	@DataProvider(name="dataProviderTriangle")
	public Object [][] createDataTriangle(){
		double A=3;//sides of
		double B=3;//equilateral
		double C=3;//triangle
		return new Object[][]
			{
				{"Equilateral", new ArrayList<Double>(Arrays.asList(A, B , C))},				
			};		
	}
  @Test(dataProvider = "dataProviderTriangle")
  public void testRectangularTriangle(String defenition, ArrayList<Double> parameters) {
	  final int TR_EQUILATERAL = 1; // ��������������
      final int TR_ISOSCELES = 2;   // ��������������
	  //final int TR_ORDYNARY = 4;    // �������
	  //final int TR_RECTANGULAR = 8; // �������������
	  double side_a=(Double)(parameters.get(0));
	  double side_b=(Double)(parameters.get(1));
	  double side_c=(Double)(parameters.get(2));
	  Triangle triangleToTest = new Triangle(side_a, side_b, side_c);	    
	  Assert.assertEquals(triangleToTest.detectTriangle(), TR_EQUILATERAL+TR_ISOSCELES);
  }
}
