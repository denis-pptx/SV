
import java.util.ArrayList;
import java.util.Arrays;

import org.testng.Assert;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import triangle.Triangle;

public class TstExceptionNumberFormat {
	@DataProvider(name="dataProviderTriangle")
	public Object [][] createDataTriangle(){
		double A=2;//sides 
		double B=Double.NaN;//of
		double C=Double.MAX_VALUE;//triangle
		return new Object[][]
			{
				{"Just Triangle", new ArrayList<Double>(Arrays.asList(A, B , C))},				
			};		
	}
  @Test(dataProvider = "dataProviderTriangle", expectedExceptions =NumberFormatException.class)
  public void testRectangularTriangle(String defenition, ArrayList<Double> parameters) {	  
	  double side_a=(Double)(parameters.get(0));
	  double side_b=(Double)(parameters.get(1));
	  double side_c=(Double)(parameters.get(2));
	  Triangle triangleToTest = new Triangle(side_a, side_b, side_c);
	  Assert.assertTrue(triangleToTest.checkTriangle());

  }
}
