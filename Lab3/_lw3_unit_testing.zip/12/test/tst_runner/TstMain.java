
import org.testng.annotations.Test;

public class TstMain {
  @Test
  public void f() {
  }
}