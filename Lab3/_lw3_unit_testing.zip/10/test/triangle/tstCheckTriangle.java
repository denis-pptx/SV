
import static org.junit.Assert.*;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.Parameterized;
import org.junit.runners.Parameterized.Parameters;

public class tstCheckTriangle {

	Triangle triangle = null;
	
	//check constructor
	@Test
	public void tst_constructor() {
		triangle = new Triangle(7, 8, 9);		
	}

	//outpot message
	@Test
	public void tst_getMessage() {
		String message = "";
		assertFalse(message.isEmpty());
	}

	//check square
	@Test
	public void tst_getSquare() {
		double sqExp = 0;
		double sqPass = 0;
		double p = 0;
		triangle = new Triangle(3, 3, 5);
		p = 11.0;
		sqExp = Math.sqrt(p * (p - 3) * (p - 3) * (p - 5));
		sqPass = triangle.getSquare();
		assertEquals(sqExp, sqPass, 0.001);
	}
	
	@Test
	public void tst_detectTriangle1() {
		triangle = new Triangle(5, 3, 3);
		assertEquals(2, triangle.detectTriangle());
	}
	
	@Test
	public void tst_detectTriangle2() {
		triangle = new Triangle(3, 5, 3);
		assertEquals(2, triangle.detectTriangle());
	}

	@Test
	public void tst_detectTriangle3() {
		triangle = new Triangle(3, 3, 5);
		assertEquals(2, triangle.detectTriangle());
	}

	@Test
	public void tst_detectTriangle4() {
		triangle = new Triangle(5, 5, 5);
		assertEquals(1, triangle.detectTriangle());
	}

	@Test
	public void tst_detectTriangle5() {
		triangle = new Triangle(7, 8, 9);
		assertEquals(4, triangle.detectTriangle());
	}

	@Test
	public void tst_detectTriangle6() {
		triangle = new Triangle(6, 8, 10);
		assertEquals(8, triangle.detectTriangle());
	}

	@Test
	public void tst_detectTriangle7() {
		triangle = new Triangle(1, 1, 1);
		assertEquals(0, triangle.detectTriangle()); // 0 - for a non-existent
													// triangle
	}

	@Test
	public void tst_detectTriangle8() {
		triangle = new Triangle(2, 2, 4);
		assertEquals(0, triangle.detectTriangle());
	}

	@Test
	public void tst_detectTriangle9() {
		triangle = new Triangle(1, 2, 3);
		assertEquals(0, triangle.detectTriangle());
	}

	 @Test
	 public void tst_detectTriangle10(){
	 triangle=new Triangle(0, 0, 0);
	 assertEquals(0, triangle.detectTriangle());
	 }

	@Test
	public void tst_checkTriangle1() {
		double a = 2;
		double b = 2;
		double c = 2;
		assertFalse((a <= 0) || (b <= 0) || (c <= 0));
	}

	@Test
	public void tst_checkTriangle2() {
		double a = 4;
		double b = 2;
		double c = 3;
		assertTrue((a + b <= c) || (a + c <= b) || (b + c <= a));
	}

	@Test
	public void tst_checkTriangle3() {
		double a = 0;
		double b = 0;
		double c = 0;
		assertTrue((a <= 0) || (b <= 0) || (c <= 0));
	}

	@Test
	public void tst_checkTriangle4() {
		double a = 3;
		double b = 2;
		double c = 0;
		assertTrue((a <= 0) || (b <= 0) || (c <= 0));
	}

	@Test
	public void tst_checkTriangle5() {
		double a = -2;
		double b = 3;
		double c = 2;
		assertTrue((a <= 0) || (b <= 0) || (c <= 0));
	}

	@Test
	public void tst_checkTriangle6() {
		double a = Double.MAX_VALUE;
		double b = Double.MAX_VALUE;
		double c = 1;
		assertFalse((a + b <= c) || (a + c <= b) || (b + c <= a));
	}

	@Test
	public void tst_checkTriangle7() {
		double c = -2;
		assertFalse(c <= 0);
	}

	@RunWith(value = Parameterized.class)
	public static class Extended {
		private ArrayList<Double> parameters;

		@Parameters
		public static Collection<Object[]> set_of_parameters() {
			return Arrays
					.asList(new Object[][] { { "EQUILATERAL", new ArrayList<Double>(Arrays.asList(5.0, 5.0, 5.0)) },
							{ "ISOSCELES", new ArrayList<Double>(Arrays.asList(3.0, 3.0, 5.0)) } });
		}

		public Extended(ArrayList<Double> parameters) {
			this.parameters = parameters;
		}

		@Test
		public void tstCollect() {

			System.out.println(parameters);
			Double sideA = (Double) parameters.get(0);
			Double sideB = (Double) parameters.get(1);
			Double sideC = (Double) parameters.get(2);
			assertTrue(sideA.equals(sideB) && sideB.equals(sideC) && sideA.equals(sideC));
		}

	}

}
