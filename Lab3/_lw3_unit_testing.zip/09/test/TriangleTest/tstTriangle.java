
import static org.junit.Assert.*;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import triangle.Triangle;

public class tstTriangle {

	@Before
	public void setUp() throws Exception {
	}

	@After
	public void tearDown() throws Exception {
	}

	@Test
	public void tstWhereSideAEqualNull() {
		double a = 0;
		double b = 1.0;
		double c = 2.0;
		Triangle tr = new Triangle(a, b, c);
		tr.checkTriangle();
		assertEquals("a<=0", tr.getMessage());
	}
	
	@Test
	public void tstWhereSideBEqualNull() {
		double a = 1.0;
		double b = -2.3;
		double c = 2.0;
		Triangle tr = new Triangle(a, b, c);
		tr.checkTriangle();
		assertEquals("b<=0", tr.getMessage());
	}
	
	@Test
	public void tstWhereSideCEqualNull() {
		double a = 1.0;
		double b = 2.0;
		double c = -5;
		Triangle tr = new Triangle(a, b, c);
		tr.checkTriangle();
		assertEquals("c<=0", tr.getMessage());
	}
	
	@Test
	public void tstWhereSumABEqualOrLessC() {
		double a = 1.0;
		double b = 2.0;
		double c = 3.0;
		Triangle tr = new Triangle(a, b, c);
		tr.checkTriangle();
		assertEquals("a+b<=c", tr.getMessage());
	}
	
	@Test
	public void tstWhereSumACEqualOrLessB() {
		double a = 1.0;
		double b = 2.0;
		double c = 3.0;
		Triangle tr = new Triangle(a, b, c);
		tr.checkTriangle();
		assertEquals("a+c<=b", tr.getMessage());
	}
	
	@Test
	public void tstWhereSumBCEqualOrLessA() {
		double a = 1.0;
		double b = 2.0;
		double c = 3.0;
		Triangle tr = new Triangle(a, b, c);
		tr.checkTriangle();
		assertEquals("b+c<=a", tr.getMessage());
	}
	
	@Test
	public void tstDetectTriangleOfRECTANGULAR() {
		double a = 6.0;
		double b = 8.0;
		double c = 10.0;
		Triangle tr = new Triangle(a, b, c);
		assertEquals(8, tr.detectTriangle());
	}
	
	@Test
	public void tstDetectTriangleEQUILATERAL() {
		double a = 3.5;
		double b = 3.5;
		double c = 3.5;
		Triangle tr = new Triangle(a, b, c);
		assertEquals(1, tr.detectTriangle());
	}
	
	@Test
	public void tstDetectTriangleOfISOSCELES() {
		double a = 3.0;
		double b = 4.0;
		double c = 3.0;
		Triangle tr = new Triangle(a, b, c);
		assertEquals(2, tr.detectTriangle());
	}
	
	@Test
	public void tstDetectTriangleOfORDYNARY() {
		double a = 3.0;
		double b = 4.0;
		double c = 6.0;
		Triangle tr = new Triangle(a, b, c);
		assertEquals(4, tr.detectTriangle());
	}
	
	@Test
	public void tstDetectTriangleOfRECTANGULARMinus() {
		double a = -6.0;
		double b = 0;
		double c = -10.0;
		Triangle tr = new Triangle(a, b, c);
		assertEquals("Size can't be negative", tr.detectTriangle());
	}
	
	@Test
	public void tstDetectTriangleEQUILATERALMinus() {
		double a = -3.5;
		double b = -3.5;
		double c = -3.5;
		Triangle tr = new Triangle(a, b, c);
		assertEquals("Size can't be negative", tr.detectTriangle());
	}
	
	@Test
	public void tstDetectTriangleOfISOSCELESMinus() {
		double a = -3.0;
		double b = 0;
		double c = -3.0;
		Triangle tr = new Triangle(a, b, c);
		assertEquals("Size can't be negative", tr.detectTriangle());
	}
	
	@Test
	public void tstDetectTriangleOfORDYNARYMinus() {
		double a = -3.0;
		double b = -4.0;
		double c = 0;
		Triangle tr = new Triangle(a, b, c);
		assertEquals("Size can't be negative", tr.detectTriangle());
	}
	
}
