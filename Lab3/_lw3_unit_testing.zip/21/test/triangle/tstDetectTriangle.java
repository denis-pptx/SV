
import org.testng.annotations.Test;
import org.testng.annotations.BeforeMethod;
import org.testng.Assert;
import org.testng.annotations.AfterMethod;

public class tstDetectTriangle {
  Triangle tr;
  
  @Test
  public void EquilateralTriangle() {
	  tr = new Triangle(3.0, 3.0, 3.0);
	  Assert.assertEquals(tr.detectTriangle(), tr.TR_EQUILATERAL|tr.TR_ISOSCELES);
  }
  
  @Test
  public void IsoscelesTriangleAB() {
	  tr = new Triangle(3.0, 3.0, 1.0);
	  Assert.assertEquals(tr.detectTriangle(), tr.TR_ISOSCELES);
  }
  
  @Test
  public void IsoscelesTriangleAC() {
	  tr = new Triangle(3.0, 1.0, 3.0);
	  Assert.assertEquals(tr.detectTriangle(), tr.TR_ISOSCELES);
  }
  
  @Test
  public void IsoscelesTriangleBC() {
	  tr = new Triangle(1.0, 3.0, 3.0);
	  Assert.assertEquals(tr.detectTriangle(), tr.TR_ISOSCELES);
  }

  @Test(enabled=false) //Not working because of 0.00000000000001 problem
  public void IsoscelesRectangularTriangleAB() {
	  tr = new Triangle(4.0, 4.0, 4*Math.sqrt(2));
	  Assert.assertEquals(tr.detectTriangle(), tr.TR_ISOSCELES|tr.TR_RECTANGULAR);
  }
  
  @Test(enabled=false) //Not working because of 0.00000000000001 problem
  public void IsoscelesRectangularTriangleAC() {
	  tr = new Triangle(4.0, 4*Math.sqrt(2), 4.0);
	  Assert.assertEquals(tr.detectTriangle(), tr.TR_ISOSCELES|tr.TR_RECTANGULAR);
  }
  
  @Test(enabled=false) //Not working because of 0.00000000000001 problem
  public void IsoscelesRectangularTriangleBC() {
	  tr = new Triangle(4*Math.sqrt(2), 4.0, 4.0);
	  Assert.assertEquals(tr.detectTriangle(), tr.TR_ISOSCELES|tr.TR_RECTANGULAR);
  }
  
  @Test
  public void OrdynaryTriangle() {
	  tr = new Triangle(2.0, 3.0, 7.0);
	  Assert.assertEquals(tr.detectTriangle(), tr.TR_ORDYNARY);
  }
  
  @Test
  public void RectangularTriangleAB_C() {
	  tr = new Triangle(3.0, 4.0, 5.0);
	  Assert.assertEquals(tr.detectTriangle(), tr.TR_RECTANGULAR);
  }
  
  @Test
  public void RectangularTriangleAC_B() {
	  tr = new Triangle(3.0, 5.0, 4.0);
	  Assert.assertEquals(tr.detectTriangle(), tr.TR_RECTANGULAR);
  }

  @Test
  public void RectangularTriangleBC_A() {
	  tr = new Triangle(5.0, 3.0, 4.0);
	  Assert.assertEquals(tr.detectTriangle(), tr.TR_RECTANGULAR);
  }
  
 
  
  

  @AfterMethod
  public void tearDown() {
	  tr = null;
  }

}
