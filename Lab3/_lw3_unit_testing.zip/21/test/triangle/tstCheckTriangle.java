import org.testng.annotations.Test;

import triangle.Triangle;

import org.testng.Assert;
import org.testng.annotations.AfterMethod;

public class tstCheckTriangle {
	Triangle tr;
	
	@Test
	public void tstFirstNegative() {
		tr = new Triangle(-10.0, 2.0, 2.0);
		Assert.assertEquals(tr.checkTriangle(), false);
		Assert.assertEquals(tr.getMessage(), "a<=0");
	}

	@Test
	public void tstSecondNegative() {
		tr = new Triangle(1.0, -20.0, 2.0);
		Assert.assertEquals(tr.checkTriangle(), false);
		Assert.assertEquals(tr.getMessage(), "b<=0");
	}

	@Test
	public void tstThirdNegative() {
		tr = new Triangle(1.0, 2.0, -20.0);
		Assert.assertEquals(tr.checkTriangle(), false);
		Assert.assertEquals(tr.getMessage(), "c<=0");
	}

	@Test
	public void tstFirstEqualsNull() {
		tr = new Triangle(0.0, 2.0, 2.0);
		Assert.assertEquals(tr.checkTriangle(), false);
		Assert.assertEquals(tr.getMessage(), "a<=0");
	}

	@Test
	public void tstSecondEqualsNull() {
		tr = new Triangle(1.0, 0.0, 2.0);
		Assert.assertEquals(tr.checkTriangle(), false);
		Assert.assertEquals(tr.getMessage(), "b<=0");
	}   

	@Test
	public void tstThirdEqualsNull() {
		tr = new Triangle(1.0, 2.0, 0.0);
		Assert.assertEquals(tr.checkTriangle(), false);
		Assert.assertEquals(tr.getMessage(), "c<=0");
	}

	@Test
	public void tstABSumBiggerC() {
		tr = new Triangle(3.0, 2.0, 4.0);
		Assert.assertEquals(tr.checkTriangle(), true);
	}

	@Test
	public void tstABSumEqualsC() {
		tr = new Triangle(3.0, 2.0, 5.0);
		Assert.assertEquals(tr.checkTriangle(), false);
		Assert.assertEquals(tr.getMessage(), "a+b<=c");
	}

	@Test
	public void tstABSumSmallerC() {
		tr = new Triangle(1.0, 2.0, 4.0);
		Assert.assertEquals(tr.checkTriangle(), false);
		Assert.assertEquals(tr.getMessage(), "a+b<=c");
	}
	
	@Test
	public void tstACSumBiggerB() {
		tr = new Triangle(3.0, 4.0, 2.0);
		Assert.assertEquals(tr.checkTriangle(), true);
	}

	@Test
	public void tstACSumEqualsB() {
		tr = new Triangle(3.0, 5.0, 2.0);
		Assert.assertEquals(tr.checkTriangle(), false);
		Assert.assertEquals(tr.getMessage(), "a+c<=b");
	}

	@Test
	public void tstACSumSmallerB() {
		tr = new Triangle(1.0, 4.0, 2.0);
		Assert.assertEquals(tr.checkTriangle(), false);
		Assert.assertEquals(tr.getMessage(), "a+c<=b");
	}

	@Test
	public void tstBCSumBiggerA() {
		tr = new Triangle(4.0, 2.0, 3.0);
		Assert.assertEquals(tr.checkTriangle(), true);
	}

	@Test
	public void tstBCSumEqualsA() {
		tr = new Triangle(5.0, 2.0, 3.0);
		Assert.assertEquals(tr.checkTriangle(), false);
		Assert.assertEquals(tr.getMessage(), "b+c<=a");
	}

	@Test
	public void tstBCSumSmallerA() {
		tr = new Triangle(4.0, 2.0, 1.0);
		Assert.assertEquals(tr.checkTriangle(), false);
		Assert.assertEquals(tr.getMessage(), "b+c<=a");
	}
	
	@AfterMethod
	public void tearDown() {
		tr = null;
	}

}
