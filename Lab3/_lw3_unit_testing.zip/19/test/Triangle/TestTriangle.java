
import org.testng.annotations.Test;
import org.testng.Assert;


import triangle.Triangle;

public class TestTriangle {
	
  @Test
  public void testDetectTriangle() {
	  Triangle trn = new Triangle(5, 5, 4);
	  int i = trn.checkTriangle();
	
	  Assert.assertEquals(2, 2);
	  
	 
	  
  }
}
