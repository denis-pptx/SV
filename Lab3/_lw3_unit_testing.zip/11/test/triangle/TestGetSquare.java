
import static org.junit.Assert.*;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;

import org.junit.After;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.Parameterized;
import org.junit.runners.Parameterized.Parameters;

@RunWith(Parameterized.class)
public class TestGetSquare {

	private ArrayList<Double> sideValues;
	private double expSquare;
	private Triangle triangle;
		
	
	@Parameters
	public static Collection<Object[]> params() {
		return Arrays.asList( new Object[][] {
			//positive
			{ 110.851, new ArrayList<Double>(Arrays.asList(16.0, 16.0, 16.0)) }, 		//0	equilateral			
			{ 385.653, new ArrayList<Double>(Arrays.asList(28.0, 28.0, 43.0)) },		//1	isosceles			
			{ 1875.126, new ArrayList<Double>(Arrays.asList(56.0, 67.0, 86.0)) },	 	//2	simple
			{ 11543.999, new ArrayList<Double>(Arrays.asList(156.0, 148.0, 215.03)) },  //3	rectangular
			{ 67711.999, new ArrayList<Double>(Arrays.asList(368.0, 368.0, 520.43)) },  //4	rectangular isosceles
			
			//max nums
			{ Double.NaN, new ArrayList<Double>(Arrays.asList(Double.MAX_VALUE, 368.0, 400.0)) },  //5	max 1
			{ Double.POSITIVE_INFINITY, new ArrayList<Double>(Arrays.asList(Double.MAX_VALUE, Double.MAX_VALUE, 400.0)) },  //6	max 2
			{ Double.POSITIVE_INFINITY, new ArrayList<Double>(Arrays.asList(Double.MAX_VALUE, Double.MAX_VALUE, Double.MAX_VALUE)) },  //7	max 3
					
		
		});
	}
	
	public TestGetSquare (double square, ArrayList<Double> params) {
		sideValues = params;
		this.expSquare = square;
	}
	
	@Test
	public void testSquareCalc() {
		System.out.println("testSquareCalc() : " + sideValues);
		
		Double side_a = sideValues.get(0);
		Double side_b = sideValues.get(1);
		Double side_c = sideValues.get(2);
		triangle = new Triangle(side_a, side_b, side_c);

		double factSquare = triangle.getSquare();
		
		assertEquals(expSquare, factSquare, 0.001);
	}

	@After
	public void tearDown() throws Exception {
		triangle = null;
	}

}
