
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.Parameterized;
import org.junit.runners.Parameterized.Parameters;

@RunWith(Parameterized.class)
public class TestGetSquareNegative {

	private ArrayList<Double> sideValues;
	private double expSquare;
	private Triangle triangle;
		
	
	@Parameters
	public static Collection<Object[]> params() {
		return Arrays.asList( new Object[][] {
			//negative
				//zeroes
			{Double.NaN, new ArrayList<Double>(Arrays.asList(0.0, 17.0, 15.43)) }, 
			{Double.NaN, new ArrayList<Double>(Arrays.asList(10.0, 0.0, 16.0)) }, 
			{Double.NaN, new ArrayList<Double>(Arrays.asList(50.0, 17.0, 0.0)) }, 
			{Double.NaN, new ArrayList<Double>(Arrays.asList(0.0, 0.0, 0.0)) }, 
			
				//negative
			{Double.NaN, new ArrayList<Double>(Arrays.asList(-25.0, 17.0, 20.0)) }, 
			{Double.NaN, new ArrayList<Double>(Arrays.asList(25.0, -17.0, 20.0)) },
			{Double.NaN, new ArrayList<Double>(Arrays.asList(25.0, 17.0, -20.0)) },
			{Double.NaN, new ArrayList<Double>(Arrays.asList(-25.0, -17.0, -20.0)) },
			
				//MAX
			{Double.NaN, new ArrayList<Double>(Arrays.asList(Double.MAX_VALUE , Double.MAX_VALUE, Double.MAX_VALUE)) },
			{Double.NaN, new ArrayList<Double>(Arrays.asList(Double.MAX_VALUE + 1, Double.MAX_VALUE + 1, Double.MAX_VALUE)) },
			{Double.NaN, new ArrayList<Double>(Arrays.asList(Double.MAX_VALUE + 1, Double.MAX_VALUE + 2, Double.MAX_VALUE)) },
		});
	}
	
	public TestGetSquareNegative (double square, ArrayList<Double> params) {
		sideValues = params;
		this.expSquare = square;
	}
	
	//we think, function should throw and exception on incorrect triangle sides
	//still all cases are failed, getSquare() method should be improved by developer,
	//and we'll used this fails as an argument to do that
	@Test(expected = Exception.class)
	public void testSquareCalcNegative() {
		System.out.println("testSquareCalcNegative() : " + sideValues);
		
		Double side_a = sideValues.get(0);
		Double side_b = sideValues.get(1);
		Double side_c = sideValues.get(2);
		triangle = new Triangle(side_a, side_b, side_c);

		triangle.getSquare();
	}

	@After
	public void tearDown() throws Exception {
		triangle = null;
	}

}
