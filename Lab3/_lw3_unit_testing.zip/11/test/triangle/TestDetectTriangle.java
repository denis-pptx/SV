
import static org.junit.Assert.*;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;

import org.junit.After;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.Parameterized;
import org.junit.runners.Parameterized.Parameters;

@RunWith(Parameterized.class)
public class TestDetectTriangle {

	private ArrayList<Double> sideValues;
	private int expState;
	// just holds the states of triangle
	private static Triangle states = new Triangle(0, 0, 0);
	private Triangle triangle;

	@Parameters
	public static Collection<Object[]> params() {
		return Arrays.asList(new Object[][] { 
			
			{ states.TR_EQUILATERAL | states.TR_ISOSCELES,
				new ArrayList<Double>(Arrays.asList(16.0, 16.0, 16.0)) }, // equilateral
			
			{ states.TR_ISOSCELES,
					new ArrayList<Double>(Arrays.asList(180.0, 180.0, 200.0)) }, // isosceles

			{ states.TR_ORDYNARY,
						new ArrayList<Double>(Arrays.asList(420.0, 500.0, 600.0)) }, // simple
			
			{ states.TR_RECTANGULAR,
							new ArrayList<Double>(Arrays.asList(3.0, 4.0, 5.0)) }, // rect
			
			{ states.TR_RECTANGULAR | states.TR_ISOSCELES,
								new ArrayList<Double>(Arrays.asList(4.0, 4.0, 5.66)) }, // rect isosc
		
		
			//I think negative cases makes no sense, because all of them will be failed
			//(e.g. 0, 0, 0 will return incorrect state, but this triangle is not valid
			//and the function provided for working with CORRECT values)
			{ states.TR_EQUILATERAL | states.TR_ISOSCELES,
									new ArrayList<Double>(Arrays.asList(0.00, 0.00, 0.00)) } 
		});
	}

	public TestDetectTriangle(int state, ArrayList<Double> params) {
		expState = state;
		sideValues = params;
	}

	@After
	public void tearDown() throws Exception {
		triangle = null;
	}

	@Test
	public void testDetectTriangle() {
		System.out.println("testDetectTriangle() : " + sideValues);

		Double side_a = sideValues.get(0);
		Double side_b = sideValues.get(1);
		Double side_c = sideValues.get(2);
		triangle = new Triangle(side_a, side_b, side_c);

		int factState = triangle.detectTriangle();

		assertEquals(expState, factState);
	}

}
