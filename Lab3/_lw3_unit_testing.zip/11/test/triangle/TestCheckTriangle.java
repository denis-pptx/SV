
import static org.junit.Assert.*;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;

import org.junit.After;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.Parameterized;
import org.junit.runners.Parameterized.Parameters;

@RunWith(Parameterized.class)
public class TestCheckTriangle {

	private ArrayList<Double> sideValues;
	private String outputMarker;
	private boolean methodFlag = false;
	private Triangle triangle;
	
	@Parameters
	public static Collection<Object[]> params() {
		return Arrays.asList( new Object[][] {
			//positive
			{ "", true, new ArrayList<Double>(Arrays.asList(2.0, 2.0, 2.0)) }, //equilateral
			{ "", true, new ArrayList<Double>(Arrays.asList(4.0, 4.0, 2.5)) }, //isosceles
			{ "", true, new ArrayList<Double>(Arrays.asList(4.0, 3.0, 6.0)) }, //simple
			{ "", true, new ArrayList<Double>(Arrays.asList(3.0, 4.0, 5.0)) }, //rectangular
			{ "", true, new ArrayList<Double>(Arrays.asList(160.0, 160.0, 226.27)) }, //rectangular isosceles
			
			{ "", true, new ArrayList<Double>(Arrays.asList(Double.MAX_VALUE, Double.MAX_VALUE, Double.MAX_VALUE)) }, //equilateral MAX
			{ "", true, new ArrayList<Double>(Arrays.asList(Double.MAX_VALUE, Double.MAX_VALUE, Double.MAX_VALUE - 1)) }, //isosceles
			{ "", true, new ArrayList<Double>(Arrays.asList(Double.MAX_VALUE, Double.MAX_VALUE - 2, Double.MAX_VALUE - 1)) }, //simple
			{ "", true, new ArrayList<Double>(Arrays.asList(Double.MAX_VALUE, Double.MAX_VALUE, Double.MAX_VALUE)) }, //rectangular
			
			//negative
				//sum of sides less than third
			{ "a<=0", false, new ArrayList<Double>(Arrays.asList(-4.0, 2.0, 2.0)) }, 
			{ "b<=0", false, new ArrayList<Double>(Arrays.asList(4.0, -2.0, 2.0)) }, 
			{ "c<=0", false, new ArrayList<Double>(Arrays.asList(4.0, 2.0, -2.0)) }, 
				//zeroes
			{ "a<=0", false, new ArrayList<Double>(Arrays.asList(0.0, 2.0, 2.0)) }, 
			{ "b<=0", false, new ArrayList<Double>(Arrays.asList(4.0, 0.0, 2.0)) }, 
			{ "c<=0", false, new ArrayList<Double>(Arrays.asList(4.0, 2.0, 0.0)) }, 
			
			{ "a+b<=c", false, new ArrayList<Double>(Arrays.asList(14.0, 20.0, 35.0)) }, 
			{ "a+c<=b", false, new ArrayList<Double>(Arrays.asList(10.0, 20.0, 5.0)) }, 
			{ "b+c<=a", false, new ArrayList<Double>(Arrays.asList(20.0, 14.0, 5.0)) }, 
			
		});
	}
	
	public TestCheckTriangle (String output, boolean flag, ArrayList<Double> params) {
		outputMarker = output;
		sideValues = params;
		methodFlag = flag;
	}
	
	@Test
	public void testCheckTriangle() {
		System.out.println("checkTriangle() : " + outputMarker+": " + sideValues);
		
		Double side_a = sideValues.get(0);
		Double side_b = sideValues.get(1);
		Double side_c = sideValues.get(2);
		triangle = new Triangle(side_a, side_b, side_c);
		
		assertEquals(methodFlag, triangle.checkTriangle());
		assertEquals(outputMarker, triangle.getMessage());
	}
	
	@After
	public void tearDown() throws Exception {
		triangle = null;
	}
}
