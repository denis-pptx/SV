
import org.junit.runner.RunWith;
import org.junit.runners.Suite;


@RunWith(Suite.class)
@Suite.SuiteClasses({
	TestCheckTriangle.class,
	TestDetectTriangle.class,
	TestGetSquare.class,
	TestGetSquareNegative.class,
	})
public class _TestRunner {


}
