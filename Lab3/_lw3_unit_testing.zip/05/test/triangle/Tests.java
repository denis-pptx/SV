
import static org.junit.Assert.*;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

public class Tests {
	private Triangle tr;
	private double a;
	private double b;
	private double c;

	@Before
	public void tst_Preparation() {
		this.tr = new Triangle(a, b, c);
	}

	@After
	public void tst_Finalization() {
		this.tr = null;
	}

	@Test
	public void tst_Values() {

		assertTrue(this.tr.getMessage() == null);
		assertTrue(this.tr.getSquare() == 0.0);
	}

	@Test
	public void tst_checkA1() {
		boolean n = this.tr.checkTriangle();
		this.a = -5;
		assertEquals("a<=0", this.tr.getMessage());
	}

	@Test
	public void tst_checkA2() {
		boolean n = this.tr.checkTriangle();
		this.a = -5;
		assertEquals(false, this.tr.checkTriangle());
	}

	@Test
	public void tst_checkC1() {
		this.c = -2;
		assertEquals(false, this.tr.checkTriangle());
	}

	@Test
	public void tst_checkABC() {
		this.a = -5;
		this.b = 0;
		this.c = 5;
		assertEquals(false, this.tr.checkTriangle());
	}

	@Test
	public void tst_checkC2() {
		this.c = -2;
		assertEquals("c<=0", this.tr.getMessage());
	}

	@Test
	public void tst_detectTriangle1() {
		this.a = 3;
		this.b = 3;
		this.c = 18;
		assertEquals(this.tr.TR_RECTANGULAR, this.tr.detectTriangle());
	}

	@Test
	public void tst_detectTriangle2() {
		this.a = 3;
		this.b = 3;
		this.c = 3;
		assertEquals(1, this.tr.detectTriangle());
	}

	@Test
	public void tst_getSquare() {
		double p = (a + b + c) / 2;
		assertTrue(Math.sqrt(p * (p - a) * (p - b) * (p - c)) == tr.getSquare());

	}

}
