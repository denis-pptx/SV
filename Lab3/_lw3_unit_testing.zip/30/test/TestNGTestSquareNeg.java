import org.testng.Assert;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;
import triangle.Triangle;

public class TestNGTestSquareNeg {

    @DataProvider
    public Object[][] setUpTriangleForSquareNeg() {
        return new Object[][]{
                {new Double[]{0.0, 0.0, 0.0}, 0.0},
                {new Double[]{-3.0, -5.0, -6.0}, 7.48},
                {new Double[]{1.1E308, 1.1E308, 1.1E308}, Double.POSITIVE_INFINITY},
                {new Double[]{Double.NaN, Double.NaN, Double.NaN}, Double.NaN},};
    }


    @Test(dataProvider = "setUpTriangleForSquareNeg")
    public void testCheckDetectTriangle(Double[] array, double expected) {

        Triangle tr = new Triangle(array[0], array[1], array[2]);

        Assert.assertEquals(tr.getSquare(), expected, 0.01);
    }
}
