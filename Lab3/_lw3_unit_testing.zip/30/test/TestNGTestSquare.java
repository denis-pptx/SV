import org.testng.Assert;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;
import triangle.Triangle;

public class TestNGTestSquare {
    @DataProvider
    public Object[][] setUpTriangleForSquare() {
        return new Object[][]{
                {new Double[]{3.0, 4.0, 5.0}, 6.0},
                {new Double[]{3.3333, 3.3333, 3.3333}, 4.81115601868314168854},
                {new Double[]{1.0000000000000009191, 1.0000000000000009191, 1.0000000000000009191}, 0.43301270189222013096},};
    }


    @Test(dataProvider = "setUpTriangleForSquare")
    public void testCheckDetectTriangle(Double[] array, double expected) {

        Triangle tr = new Triangle(array[0], array[1], array[2]);

        Assert.assertEquals(tr.getSquare(), expected, 0.000000000000000000001);
    }
}
