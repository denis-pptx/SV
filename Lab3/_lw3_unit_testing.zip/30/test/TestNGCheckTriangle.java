import org.testng.Assert;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;
import triangle.Triangle;


public class TestNGCheckTriangle {


    @DataProvider
    public Object[][] setUpTriangle() {
        return new Object[][]{
                {new Double[]{-1.0, 2.0, 3.0}, "a<=0"},
                {new Double[]{-0.0, 2.0, 3.0}, "a<=0"},
                {new Double[]{1.0, 0.0, 0.0}, "b<=0"},
                {new Double[]{1.0, -2.0, 0.0}, "b<=0"},
                {new Double[]{1.0, 2.0, -3.0}, "c<=0"},
                {new Double[]{1.0, 2.0, 0.0}, "c<=0"},
                {new Double[]{1.0, 1.0, 3.0}, "a+b<=c"},
                {new Double[]{50.0, 83.0, 3.0}, "a+c<=b"},
                {new Double[]{150.0, 3.0, 3.0}, "b+c<=a"},
                {new Double[]{3.0, 3.0, 3.0}, ""},
        };
    }


    @Test(dataProvider = "setUpTriangle")
    public void testCheckTriangle(Double[] array, String expected) {

        Triangle tr = new Triangle(array[0], array[1], array[2]);
        tr.checkTriangle();
        Assert.assertEquals(tr.getMessage(), expected);
    }

}
