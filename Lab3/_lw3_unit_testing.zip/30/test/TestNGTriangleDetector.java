import org.testng.Assert;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;
import triangle.Triangle;

public class TestNGTriangleDetector {


    @DataProvider
    public Object[][] setUpTriangleForDetectTriangle() {
        return new Object[][]{
                {new Double[]{5.0, 5.0, 5.0}, 1},
                {new Double[]{2.0, 2.0, 4.0}, 8},
                {new Double[]{3.0, 3.0, 2.0}, 2},
                {new Double[]{5.0, 3.0, 4.0}, 4},};
    }


    @Test(dataProvider = "setUpTriangleForDetectTriangle")
    public void testCheckDetectTriangle(Double [] array, int expected) {

        Triangle tr = new Triangle(array[0],array[1],array[2]);

        Assert.assertEquals(tr.detectTriangle(),expected,"NOT TRIANGLE" );
    }
}
