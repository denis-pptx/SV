import org.testng.Assert;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;
import triangle.Triangle;

public class TestNGTriangleDetectorNegative {


    @DataProvider
    public Object[][] setUpTriangleForDetectTriangleNeg() {
        return new Object[][]{
                {new Double[]{0.0, 0.0, 0.0}, 1},
                {new Double[]{-1.0, -2.0, -3.0}, 4},
                {new Double[]{3.333333333333333333333333333, 3.333333333333333333333333333333, 3.333333333333333333333333333333333333333333}, 1},
        };
    }


    @Test(dataProvider = "setUpTriangleForDetectTriangleNeg")
    public void testCheckDetectTriangle(Double[] array, int expected) {

        Triangle tr = new Triangle(array[0], array[1], array[2]);

        Assert.assertEquals(tr.detectTriangle(), expected);
    }


}
