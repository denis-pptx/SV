
import org.testng.annotations.Test;
import org.testng.Assert;
import org.testng.annotations.DataProvider;

public class TestTriangleSquare {
  @Test(dataProvider = "square data")
  public void f(double a, double b, double c) {
	  Triangle triangle = new Triangle(a, b, c);
	  double p;
		p = (a+b+c)/2;
		p=Math.sqrt(p*(p-a)*(p-b)*(p-c));
	  Assert.assertEquals(p, triangle.getSquare());
  }

  @DataProvider(name = "square data")
  public Object[][] dp() {
    return new Object[][] {
      new Object[] { 1.0, 2.0, 2.0},
    };
  }
}
