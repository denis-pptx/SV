
import org.testng.annotations.Test;
import org.testng.Assert;
import org.testng.annotations.DataProvider;

public class TestTriangleCheck {
	 @Test(dataProvider = "dp")
	  public void f(double a, double b, double c, String message) {
		 Triangle triangle = new Triangle(a,b,c);
		 triangle.checkTriangle();
		 Assert.assertEquals( triangle.getMessage(),message);
	  }

	  @DataProvider(name = "dp")
	  public Object[][] dp() {
	    return new Object[][] {
	      new Object[] { 0.0, 1.0, 2.0, "a<=0" },
	      new Object[] { 1.0, 0.0, 2.0, "b<=0" },
	      new Object[] { 1.0, 2.0, 0.0, "c<=0" },
	      new Object[] { 1.0, 2.0, 3.0, "a+b<=c" },
	      
	     
	    };
	  } 
}
