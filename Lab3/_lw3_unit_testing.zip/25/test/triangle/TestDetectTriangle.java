
import org.testng.annotations.Test;
import org.testng.Assert;
import org.testng.annotations.DataProvider;

public class TestDetectTriangle {
 @Test(dataProvider = "TR_ISOSCELES")
  public void tstTrinagleCheck1(double a, double b, double c, int i) {
	  Triangle triangle = new Triangle(a, b, c);
	  Assert.assertEquals( triangle.detectTriangle(),i);
	  
  }
  @Test(dataProvider = "TR_EQUILATERAL")
  public void tstTrinagleCheck2(double a, double b, double c, int i) {
	  Triangle triangle = new Triangle(a, b, c);
	  Assert.assertEquals( triangle.detectTriangle(),i);
	  
  }
 @DataProvider(name = "TR_ISOSCELES")
    public Object[][] isosceles() {
      return new Object[][] {
        new Object[] { 1.0, 1.0, 2.0, 2 },
      };
  }
  @DataProvider(name = "TR_EQUILATERAL")
  public Object[][] equilateral() {
    return new Object[][] {
      new Object[] { 3.0, 3.0, 3.0, 3 },
    };
  }
   
  
}

