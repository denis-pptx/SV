
import static org.junit.Assert.*;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

public class tst_go {

	@Before
	public void setUp() throws Exception {
	}
	Triangle tr = new Triangle(2.0, 2.0, 2.0);

	

	@Test
	public void test() {
		
		
		assertEquels(3.0,getSquare, 0.0);

}
