
import static org.junit.Assert.*;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.Parameterized;
import org.junit.runners.Parameterized.Parameters;
@RunWith(value=Parameterized.class)
public class Isosceles {

	private ArrayList<Double> parameters;
	private String marker;
	
	@Parameters
	public static Collection<Object []> set_of_parameters()
	{
		return Arrays.asList(new Object [] [] {
			{"��������������" , new ArrayList<Double>(Arrays.asList(7.0 , 7.0 , 7.0))
				
			},
            {"��������������" , new ArrayList<Double>(Arrays.asList(5.0 , 5.0 , 3.0))
				
			}
		});
		
	}
  public   Isosceles(String marker, ArrayList<Double> parameters)
{
	this.marker = marker;
	this.parameters = parameters;
}
	
	@Test
	public void test() {
		System.out.println(marker);
		System.out.println(parameters);
		System.out.println("-------------------------");
		Double side_a = (Double) parameters.get(0);
		Double side_b = (Double) parameters.get(1);
		Double side_c = (Double) parameters.get(2);
		assertTrue (side_a.equals(side_b) || side_b.equals(side_c) || side_a.equals(side_c));
	}

}
