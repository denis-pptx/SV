
import org.testng.Assert;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

public class tstCheckTriangle {

  @DataProvider
  public Object[][] zeroValues() {
    return new Object[][] {
      new Object[] { new Double(0),  new Double(1),  new Double(1) },
      new Object[] { new Double(3),  new Double(0),  new Double(4) },
      new Object[] { new Double(1),  new Double(2),  new Double(0) },
      new Object[] { new Double(0),  new Double(0),  new Double(1) },
      new Object[] { new Double(1),  new Double(0),  new Double(0) },
      new Object[] { new Double(0),  new Double(1),  new Double(0) },
      new Object[] { new Double(0),  new Double(0),  new Double(0) },
    };
  }
  
  @Test(dataProvider="zeroValues")
  public void checkZeros(Double a, Double b, Double c) {
	  Triangle tr = new Triangle(a,b,c);
	  Assert.assertEquals(tr.checkTriangle(), false);
	  tr=null;
  }
  
  @DataProvider
  public Object[][] lessThanZeroValues() {
	    return new Object[][] {
	      new Object[] { new Double(-1),  new Double(5),  new Double(3) },
	      new Object[] { new Double(3),  new Double(-1),  new Double(5) },
	      new Object[] { new Double(5),  new Double(3),  new Double(-1) },
	      new Object[] { new Double(-1),  new Double(-1),  new Double(1) },
	      new Object[] { new Double(1),  new Double(-1),  new Double(-1) },
	      new Object[] { new Double(-1),  new Double(1),  new Double(-1) },
	      new Object[] { new Double(-1),  new Double(-1),  new Double(-1) },
	    };
	  }
  
  @Test(dataProvider="lessThanZeroValues")
  public void checkNegative(Double a, Double b, Double c){
	  Triangle tr= new Triangle(a,b,c);
	  Assert.assertEquals(tr.checkTriangle(),false);
	  tr = null;
  }
  
  @DataProvider
  public Object[][] notTriangleSides() {
	    return new Object[][] {
	      new Object[] { new Double(100),  new Double(1),  new Double(1) },
	      new Object[] { new Double(3),  new Double(100),  new Double(4) },
	      new Object[] { new Double(1),  new Double(2),  new Double(100) },
	      new Object[] { new Double(Double.NEGATIVE_INFINITY),  new Double(Double.POSITIVE_INFINITY),  new Double(Double.POSITIVE_INFINITY) },
	      new Object[] { new Double(2),  new Double(1),  new Double(1) },
	      new Object[] { new Double(1),  new Double(2),  new Double(1) },
	      new Object[] { new Double(1),  new Double(1),  new Double(2) },
	    };
	  }
  
  @Test(dataProvider="notTriangleSides")
  public void checkNotTriangleSides(Double a, Double b, Double c){
	  Triangle tr= new Triangle(a,b,c);
	  Assert.assertEquals(tr.checkTriangle(),false);
	  tr = null;
  }
}
