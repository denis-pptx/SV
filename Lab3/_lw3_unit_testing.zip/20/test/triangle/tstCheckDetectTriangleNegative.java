
import org.testng.annotations.Test;
import org.testng.Assert;
import org.testng.annotations.DataProvider;

public class tstCheckDetectTriangleNegative {
  

  @DataProvider
  public Object[][] notRectangulars() {
    return new Object[][] {
      new Object[] { new Double(3), new Double(4), new Double(100) },
      new Object[] { new Double(3), new Double(100), new Double(4) },
      new Object[] { new Double(100), new Double(4), new Double(3) },
      new Object[] { new Double(Math.sqrt(2)), new Double(Math.sqrt(2)), new Double(2)}
     };
  }
  
  @Test(dataProvider = "notRectangulars")
  public void checkNotRectangulars(Double a, Double b, Double c) {
	  Triangle tr = new Triangle(a,b,c);
	  Assert.assertFalse(tr.detectTriangle()==8);
	  tr = null;
  }
  
  @DataProvider
  public Object[][] notEquilateral() {
    return new Object[][] {
      new Object[] { new Double(0), new Double(0), new Double(0) },
      new Object[] { new Double(3), new Double(4), new Double(4) },
      new Object[] { new Double(4), new Double(4), new Double(3) },
      new Object[] { new Double(4), new Double(3), new Double(4) },
     };
  }
  
  @Test(dataProvider = "notEquilateral")
  public void checkNotEquilaterals(Double a, Double b, Double c) {
	  Triangle tr = new Triangle(a,b,c);
	  Assert.assertFalse(tr.detectTriangle()==1);
	  tr = null;
  }
  
  @DataProvider
  public Object[][] notIsosceles() {
	  return new Object[][] {
		new Object[] { new Double(1), new Double(1), new Double(1)},
		new Object[] { new Double(100), new Double(1), new Double(1) },
		new Object[] { new Double(1), new Double(1), new Double(100) },
	};
  }
  
  @Test(dataProvider = "notIsosceles")
  public void checkNotIsosceles(Double a, Double b, Double c) {
	  Triangle tr = new Triangle(a,b,c);
	  Assert.assertFalse(tr.detectTriangle()==1);
	  tr = null;
  }
  
}
