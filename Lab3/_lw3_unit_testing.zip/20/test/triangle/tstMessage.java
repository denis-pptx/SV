
import java.util.ArrayList;
import java.util.Arrays;

import org.testng.Assert;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

public class tstMessage {
  
	
	@DataProvider
	  public Object[][] messages() {
	    return new Object[][] {
	      {"a<=0", new ArrayList<Double>(Arrays.asList(new Double(-1), new Double(4), new Double(5))) },
	      {"b<=0", new ArrayList<Double>(Arrays.asList(new Double(3), new Double(-4), new Double(5))) },
	      {"c<=0", new ArrayList<Double>(Arrays.asList(new Double(3), new Double(4), new Double(-5))) },
	      {"a+b<=c", new ArrayList<Double>(Arrays.asList(new Double(3), new Double(4), new Double(100))) },
	      {"a+c<=b", new ArrayList<Double>(Arrays.asList(new Double(3), new Double(100), new Double(5))) },
	      {"b+c<=a", new ArrayList<Double>(Arrays.asList(new Double(100), new Double(4), new Double(5))) },
	      };
	  }
	 
	
	 @Test(dataProvider = "messages")
	  public void checkMsg(String msg, ArrayList<Double> prms) {
		 System.out.println(msg);
		  Triangle tr = new Triangle(prms.get(0),prms.get(1),prms.get(2));
		  tr.checkTriangle();
		  Assert.assertEquals(tr.getMessage(), msg);
		  tr = null;
	  }
	
}
