
import org.testng.Assert;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

public class tstCheckDetectTrianglePositive {
  
	@DataProvider
	  public Object[][] rectangulars() {
	    return new Object[][] {
	      new Object[] { new Double(3), new Double(4), new Double(5) },
	      new Object[] { new Double(6), new Double(10), new Double(8) },
	      new Object[] { new Double(15), new Double(9), new Double(12) },
	      };
	  }
	  
	 @Test(dataProvider = "rectangulars")
	  public void checkRectangulars(Double a, Double b, Double c) {
		  Triangle tr = new Triangle(a,b,c);
		  Assert.assertEquals(tr.detectTriangle(), 8);
		  tr = null;
	  }
	  
	 @DataProvider
	  public Object[][] equilateralsAndIsosceles() {
	    return new Object[][] {
	      new Object[] { new Double(3), new Double(3), new Double(3) },
	      new Object[] { new Double(0.000000000000000000000000000001), new Double(0.000000000000000000000000000001), new Double(0.000000000000000000000000000001) },
	      new Object[] {new Double(Double.MAX_VALUE-1), new Double(Double.MAX_VALUE-1), new Double(Double.MAX_VALUE-1)}
	    };
	  }
	  
	  @Test(dataProvider = "equilateralsAndIsosceles")
	  public void checkEquilateralsAndIsosceles(Double a, Double b, Double c) {
		  Triangle tr = new Triangle(a,b,c);
		  Assert.assertEquals(tr.detectTriangle(), 3);
		  tr = null;
	  }
	  
	  @DataProvider
	  public Object[][] isosceles() {
	    return new Object[][] {
	      new Object[] { new Double(3), new Double(3), new Double(5) },
	      new Object[] { new Double(0.000000000000000000000000000001), new Double(0.000000000000000000000000000002), new Double(0.000000000000000000000000000002) },
	      new Object[] { new Double(Double.MAX_VALUE-1), new Double(Double.MAX_VALUE-3), new Double(Double.MAX_VALUE-1)}
	    };
	  }
	  
	  @Test(dataProvider = "isosceles")
	  public void checkIsosceles(Double a, Double b, Double c) {
		  Triangle tr = new Triangle(a,b,c);
		  Assert.assertEquals(tr.detectTriangle(), 2);
		  tr = null;
	  }
	  
	  @DataProvider
	  public Object[][] isoscelesAndRectangular() {
	    return new Object[][] {
	      new Object[] { new Double(Math.sqrt(2)), new Double(Math.sqrt(2)), new Double(2)},
	      new Object[] { new Double(Math.sqrt(2)), new Double(2), new Double(Math.sqrt(2))},
	      new Object[] {new Double(2), new Double(Math.sqrt(2)), new Double(Math.sqrt(2))}
	      };
	  }
	  
	  @Test(dataProvider = "isoscelesAndRectangular")
	  public void checkIsocelesAndRectangular(Double a, Double b, Double c) {
		  Triangle tr = new Triangle(a,b,c);
		  Assert.assertEquals(tr.detectTriangle(), 9);
		  tr = null;
	  }
}
