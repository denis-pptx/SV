
import org.testng.annotations.Test;
import org.testng.Assert;
import org.testng.annotations.DataProvider;

public class tstCheckSquare {

  @DataProvider
  public Object[][] dp() {
    return new Object[][] {
      new Object[] {new Double (3), new Double(4), new Double(5), new Double (3*4/2) },
      new Object[] {new Double (0.000000000000000001), new Double(0.000000000000000001), new Double(0.000000000000000001), new Double (Math.pow(0.000000000000000001,2)*Math.sqrt(3)/4) },
      new Object[] {new Double (Double.MAX_VALUE-1), new Double(Double.MAX_VALUE-1), new Double(Double.MAX_VALUE-1), new Double (Math.pow(Double.MAX_VALUE-1, 2)*Math.sqrt(3)/4) },
      new Object[] {new Double (Double.POSITIVE_INFINITY), new Double(Double.POSITIVE_INFINITY), new Double(Double.POSITIVE_INFINITY), new Double(Double.NaN) },
      
      new Object[] {new Double(3), new Double(3), new Double(3), new Double(9*Math.sqrt(3)/4)},
      new Object[] {new Double(3), new Double(3), new Double(4), new Double(4/4*Math.sqrt(4*3*3-4*4))}
    	};
    }
    
    @Test(dataProvider = "dp")
    public void checkSquare(Double a, Double b, Double c, Double square) {
    	Triangle tr = new Triangle(a,b,c);
    	Assert.assertEquals(tr.getSquare(), square,0.001);
    }
  
}
