
import org.testng.Assert;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

public class tstTriangle {

	@DataProvider(name = "checkTriangle")
	public Object[][] provider() {

		return new Object[][] { { 1, 2, 2, true }, // correct triangle
				{ 1.9, +2.1, 2.2, true }, // correct triangle (double)

				{ 0, 2, 2, false }, // side 'a' is zero
				{ 2, 0, 2, false }, // side 'b' is zero
				{ 2, 2, 0, false }, // side 'c' is zero

				{ -1, 2, 1, false }, // side 'a' is negative
				{ 1, -1, 1, false }, // side 'b' is negative
				{ 2, 2, -10, false }, // side 'c' is negative

				// case when summ of 2 sides is bigger than Double.MAX_VALUE
				{ Double.MAX_VALUE + Double.MAX_VALUE, Double.MAX_VALUE, 2, false }, { Double.POSITIVE_INFINITY, Double.POSITIVE_INFINITY, Double.POSITIVE_INFINITY, true }, { Double.MAX_VALUE, 2, 2, false }, { Double.POSITIVE_INFINITY, 2, 2, false },
				{ Double.NEGATIVE_INFINITY, 2, 2, false } };
	}

	@DataProvider(name = "detectTriangle")
	public Object[][] provider1() {

		return new Object[][] { { 2, 2, 2, 1 }, // equilateral

				{ 1.9, +2.2, 2.2, 2 }, // isosceles (double). 'b' & 'c' sides
				{ 2, +1, 2, 2 }, // isosceles. 'a' & 'c' sides
				{ 12, 12, 2, 2 }, // isosceles. 'a' & 'b' sides

				{ 1.9, 3.2, 2.2, 4 }, // ordinary triangle (double)

				{ 3, 4, 5, 8 }, // rectangular. side 'c' is gypotenyse
				{ 3, 5, 4, 8 }, // rectangular. side 'b' is gypotenyse
				{ 5, 4, 3, 8 }, // rectangular. side 'a' is gypotenyse

				// case when summ of 2 sides is bigger than Double.MAX_VALUE
				{ Double.MAX_VALUE, Double.MAX_VALUE, Double.MAX_VALUE / 2 - 10, false } };

	}

	@DataProvider(name = "getSquare")
	public Object[][] provider2() {

		return new Object[][] { { 1, 2, 2 }, // correct
				{ 1.9, +2.1, 2.2 }, // correct (double)
				{ 1.9, -2.1, 2.2 }, // incorrect (double)

				// case when summ of 2 sides is bigger than Double.MAX_VALUE
				{ Double.MAX_VALUE, Double.MAX_VALUE, Double.MAX_VALUE / 2 - 10 } };
	}

	@Test(dataProvider = "checkTriangle")
	public void tstCheckTriangle(double a, double b, double c, boolean result) {
		Triangle tr = new Triangle(a, b, c);

		Assert.assertEquals(tr.checkTriangle(), result);
	}

	@Test(dataProvider = "detectTriangle")
	public void tstDetectTriangle(double a, double b, double c, int result) {
		Triangle tr = new Triangle(a, b, c);
		Assert.assertEquals(tr.detectTriangle(), result);
	}

	@Test(dataProvider = "getSquare")
	public void tstGetSquare(double a, double b, double c) {
		Triangle tr = new Triangle(a, b, c);

		double p = (a + b + c) / 2;
		double rightSquare = Math.sqrt(p * (p - a) + (p - b) * (p - c));

		if (rightSquare > Double.MAX_VALUE)
			Assert.fail("Triangle square is Infinity");

		if (rightSquare <= 0)
			Assert.fail();

		Assert.assertEquals(tr.getSquare(), rightSquare, 0.0000001);
	}
}
