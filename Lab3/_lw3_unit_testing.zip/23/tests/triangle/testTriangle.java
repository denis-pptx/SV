
import static org.junit.Assert.*;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.List;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.Parameterized;
import org.junit.runners.Parameterized.Parameters;

@RunWith(value= Parameterized.class)
public class testTriangle {
	
	private boolean isRECTANGULAR ;	   //�������������
	private boolean isEQUILATERAL ; 	//��������������
	private boolean isISOSCELES ;   // ��������������
	private boolean isORDYNARY ;   // �������
	
	private ArrayList<Double> parameters;
	private Double 	a;
	private Double 	b;
	private Double 	c;

	
	@Parameters
	public static Collection<Object [] > set_of_parameters()
	{
		return Arrays.asList( new Object [][]{
			{"��������������" , new ArrayList<Double> (Arrays.asList(3.0, 3.0, 2.0))}, 
			{"��������������", new ArrayList<Double> (Arrays.asList(3.0, 3.0, 3.0))}, 
			{"�������", new ArrayList<Double> (Arrays.asList(13.0, 12.0, 14.0))}, 
			{"�������������", new ArrayList<Double> (Arrays.asList(3.0, 4.0, 5.0))}, 
		});
	}
	
		public testTriangle(String marker, ArrayList<Double> parameters){
			this.parameters= parameters;
		}
	

	@Before
	public void setUp() throws Exception {
		isRECTANGULAR=false; 
		isEQUILATERAL=false;
		isISOSCELES=false;
		isORDYNARY=false;
		
		
	 a = (Double) parameters.get(0);
	 b = (Double) parameters.get(1);
	 c = (Double) parameters.get(2);
	}

	@After
	public void tearDown() throws Exception {
	if(isRECTANGULAR==true) {System.out.println("side a = "+ a+ " Side b = "+ b +" Side c = "+ c + " - "  + "�������������");}
	if(isISOSCELES==true) {System.out.println("side a = "+ a+ " Side b = "+ b +" Side c = "+ c + " - "  + "��������������");}
	if(isEQUILATERAL==true) {System.out.println("side a = "+ a+ " Side b = "+ b +" Side c = "+ c + " - "  + "��������������");}
	if(isORDYNARY==true) {System.out.println("side a = "+ a+ " Side b = "+ b +" Side c = "+ c + " - "  + "�������");}
	
	}

	@Test
	public void testSidesAreAboveNull() {
		if( a<=0){
			fail("Side a <=0");
		}
		if( b<=0){
			fail("Side b <=0");
		}
		if( c<=0){
			fail("Side c <=0");
		}
	}
	
	@Test
	public void testCorrectTriangle() {
		if (a+b<=c) {
			fail(" dont works (a+b<=c)");  }
		
		if(a+c<=b){
			fail(" dont works (a+c<=b)");}
				
		if(b+c<=a){
			fail(" dont works (b+c<=a)");}
		
	
	}
	
	@Test
	public void testType(){
		if (((a*a+b*b) == (c*c)) || ((b*b + c*c) == (a*a))||((a*a + c*c )== (b*b))) {isRECTANGULAR = true; }
	else	if (((a==b )&& (a!=c)) ||((a==c )&& (b!=c)) || ((b==c )&& (c!=a))) {isISOSCELES = true; }
	else	if (a==b && b==c && a==c) {isEQUILATERAL = true; }
	else	if((a+b>c) || (a+c>b) || (b+c>a)) {isORDYNARY= true; }
		else fail("No such type!");
	}
	

	
	
}
