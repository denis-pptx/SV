
import org.testng.annotations.Test;
import org.testng.annotations.DataProvider;
import org.testng.Assert;

public class Tests {
  
	final int TR_EQUILATERAL = 1; // ��������������
	final int TR_ISOSCELES = 2;   // ��������������
	final int TR_ORDYNARY = 4;    // �������
	final int TR_RECTANGULAR = 8; // �������������
	
	Triangle triangle;
	
	
	@DataProvider ( name = "correctSidesInt")
	public Object[][] correctSidesInt() {
	return new Object[][] {
	{ 10, 12, 9 },
	};
	}
	
	@Test(groups = { "checkTriangle" }, dataProvider = "correctSidesInt")
	public void checkTriangleCorrectSidesInt( int a, int b, int c) {
		triangle = new Triangle(a, b, c);
		Assert.assertTrue(triangle.checkTriangle());
	}
	
	@DataProvider ( name = "correctSidesDouble")
	public Object[][] correctSidesDouble(double a, double b, double c) {
	return new Object[][] {
	{ 0.3, 0.9, 0.8 },
	};
	}
	
	@Test(groups = { "checkTriangle" }, dataProvider = "correctSidesDouble")
	public void checkTriangleCorrectSidesDouble( double a, double b, double c) {
		triangle = new Triangle(a, b, c);
		Assert.assertTrue(triangle.checkTriangle());
	}
	
   
    
    @DataProvider ( name = "2arquments")
	public Object[][] twoArquments() {
	return new Object[][] {
	{ 6, 5 },
	};
	}
    
    @Test(groups = { "checkTriangle" }, dataProvider = "2arguments")
	public void checkTriangleTwoArguments( double a, double b, double c) {
		triangle = new Triangle(a, b, c);
		Assert.assertFalse(triangle.checkTriangle());
	}
    
    @DataProvider ( name = "4arquments")
   	public Object[][] fourArquments() {
   	return new Object[][] {
   	{ 6, 5, 7, 8 },
   	};
   	}
       
    @Test(groups = { "checkTriangle" }, dataProvider = "4arguments")
   	public void checkTriangleFourArguments( double a, double b, double c) {
   		triangle = new Triangle(a, b, c);
   		Assert.assertFalse(triangle.checkTriangle());
   	}
    
    @DataProvider ( name = "invalidTypeString")
   	public Object[][] invalidTypeString() {
   	return new Object[][] {
   	{ "string", "string2", "string3"},
   	};
   	}
       
    @Test(groups = { "checkTriangle" }, dataProvider = "invalidTypeString")
   	public void checkTriangleInvaidTypeString( double a, double b, double c) {
   		triangle = new Triangle(a, b, c);
   		Assert.assertFalse(triangle.checkTriangle());
   	}
    
    @DataProvider ( name = "invalidTypeBoolean")
   	public Object[][] invalidTypeBooolean() {
   	return new Object[][] {
   	{ false, true, true},
   	};
   	}
       
    @Test(groups = { "checkTriangle" }, dataProvider = "invalidTypeBoolean")
   	public void checkTriangleInvaidTypeBoolean( double a, double b, double c) {
   		triangle = new Triangle(a, b, c);
   		Assert.assertFalse(triangle.checkTriangle());
   	}
    
    @DataProvider (name = "zeroSide")
   	public Object[][] zeroSide() {
   	return new Object[][] {
   	{ 0.0, 10.0, 10.0 },
   	{ 10.0, 0.0, 10.0 },
   	{ 10.0, 10.0, 0.0 },
   	};
   	}
    
    @Test(groups = { "checkTriangle" }, dataProvider = "zeroSide")
	public void checkTriangleZeroSide(double a, double b, double c) {
		triangle = new Triangle(a, b, c);
		Assert.assertFalse(triangle.checkTriangle());
	}
    
    @DataProvider (name = "equalSides")
	public Object[][] equalSides() {
	return new Object[][] {
	{ 5, 5, 5 },
	};
	}
    
    @Test(groups = { "checkTriangle" }, dataProvider = "equalSides")
	public void checkTriangleEqualSides( double a, double b, double c) {
		triangle = new Triangle(a, b, c);
		Assert.assertTrue(triangle.checkTriangle());
	}
    
    @DataProvider (name = "sumOfTwolessThird")
	public Object[][] checkTriangleSumOfTwolessThird() {
	return new Object[][] {
	{ 2, 4, 6 },
	{ 4, 2, 6},
	{ 3000, 6000, 9000 },
	};
	}
    
    @Test(groups = { "checkTriangle" }, dataProvider = "sumOfTwolessThird")
	public void checkTriangleSumOfTwolessThird(double a, double b, double c) {
		triangle = new Triangle(a, b, c);
		Assert.assertFalse(triangle.checkTriangle());
	}
    
    
    @DataProvider (name = "sumOfTwoEqualsThird")
	public Object[][] checkTriangleSumOfTwoEqualsThird() {
	return new Object[][] {
	{ 2, 4, 6 },
	{ 4, 2, 6},
	{ 3000, 6000, 9000 },
	};
	}
    
    @Test(groups = { "checkTriangle" }, dataProvider = "sumOfTwoEqualsThird")
	public void checkTriangleSumOfTwoEqualsThird(double a, double b, double c) {
		triangle = new Triangle(a, b, c);
		Assert.assertFalse(triangle.checkTriangle());
	}
    
    @DataProvider (name = "max")
	public Object[][] maxSide() {
	return new Object[][] {
		{ Double.MAX_VALUE, 5, 4 },
		{ 10, Double.MAX_VALUE, 15},
		{ 400000, 500000, Double.MAX_VALUE },
		};
		}
    
    @Test(groups = { "checkTriangle" }, dataProvider = "max")
	public void checkTriangleMaxSide(double a, double b, double c) {
		triangle = new Triangle(a, b, c);
		Assert.assertFalse(triangle.checkTriangle());
	}
	
	@DataProvider (name = "min")
	public Object[][] minSide() {
	return new Object[][] {
		{ Double.MIN_VALUE, 1, 4 },
		{ 1, Double.MIN_VALUE, 4},
		{ 4, 1, Double.MIN_VALUE },
		};
		}
	
	@Test(groups = { "checkTriangle" }, dataProvider = "min")
	public void checkTriangleMinSide(double a, double b, double c) {
		triangle = new Triangle(a, b, c);
		Assert.assertFalse(triangle.checkTriangle());
	}
    
	@DataProvider (name = "infinity")
	public Object[][] infinitySides() {
	return new Object[][] {
	{ Double.POSITIVE_INFINITY, 1789, 2000 },
	{ 10, Double.NEGATIVE_INFINITY, 10000},
	{ 6, 15, Double.NEGATIVE_INFINITY },
	};
	}
	
	@Test(groups = { "detectTriangle" }, dataProvider = "infinity")
	public void DetectTriangleInfinity(double a, double b, double c) {
		triangle = new Triangle(a, b, c);
		int result = triangle.detectTriangle();
		Assert.assertTrue((result != TR_ORDYNARY) && (result != TR_EQUILATERAL) && (result != TR_RECTANGULAR) && (result != TR_ISOSCELES));
	}
	
	@DataProvider (name = "shortSide")
	public Object[][] detectTriangleShortSide() {
	return new Object[][] {
	{ 100, 100, 20000 },
	{ 20000, 100, 100},
	{ 100, 20000, 100 },
	};
	}
	
	@Test(groups = { "detectTriangle" }, dataProvider = "shortSide")
	public void shortSidee(double a, double b, double c) {
		triangle = new Triangle(a, b, c);
		int result = triangle.detectTriangle();
		Assert.assertTrue((result != TR_ORDYNARY) && (result != TR_EQUILATERAL) && (result != TR_RECTANGULAR) && (result != TR_ISOSCELES));
	}
	
	@DataProvider (name = "expressions")
	public Object[][] detectTriangleExpressions() {
	return new Object[][] {
	{ 1*3, 2+2,  6-1},
	};
	}
	
	@Test(groups = { "detectTriangle" }, dataProvider = "expressions")
	public void detectTriangleInvalidExpressions(double a, double b, double c) {
		triangle = new Triangle(a, b, c);
		int result = triangle.detectTriangle();
		Assert.assertTrue((result != TR_ORDYNARY) && (result != TR_EQUILATERAL) && (result != TR_RECTANGULAR) && (result != TR_ISOSCELES));
	}
	
	@DataProvider (name = "nan")
	public Object[][] nanSides() {
	return new Object[][] {
	{ Double.NaN, 7, 8 },
	{ 7, Double.NaN, 8},
	{ 7, 8, Double.NaN },
	};
	}
	
	@Test(groups = { "detectTriangle" }, dataProvider = "nan")
	public void detectTriangleNanSide(double a, double b, double c) {
		triangle = new Triangle(a, b, c);
		int result = triangle.detectTriangle();
		Assert.assertTrue((result != TR_ORDYNARY) && (result != TR_EQUILATERAL) && (result != TR_RECTANGULAR) && (result != TR_ISOSCELES));
	}
	
	@DataProvider (name = "neqativeSides")
	public Object[][] nanSide() {
	return new Object[][] {
	{ -5, 7, 9 },
	{ 7, -5, 9},
	{ 7, 9, -5 },
	};
	}
	
	@Test(groups = { "detectTriangle" }, dataProvider = "negativeSides")
	public void detectTriangleNegativeSides(double a, double b, double c) {
		triangle = new Triangle(a, b, c);
		int result = triangle.detectTriangle();
		Assert.assertTrue((result != TR_ORDYNARY) && (result != TR_EQUILATERAL) && (result != TR_RECTANGULAR) && (result != TR_ISOSCELES));
	}
	
	@DataProvider (name = "zeros")
	public Object[][] zerosSides() {
	return new Object[][] {
	{ 0, 0, 0 },
	};
	}
	
	

	@Test(groups = { "detectTriangle" }, dataProvider = "zeros")
	public void detectTriangleZeros(double a, double b, double c) {
		triangle = new Triangle(a, b, c);
		int result = triangle.detectTriangle();
		Assert.assertTrue((result != TR_ORDYNARY) && (result != TR_EQUILATERAL) && (result != TR_RECTANGULAR) && (result != TR_ISOSCELES));

	}
	
	@DataProvider (name = "2equalSides")
	public Object[][] twoEqualSides() {
	return new Object[][] {
	{ 100, 100, 600 },
	{ 600, 100, 100 },
	{ 100, 600, 100 },
	};
	}
	
	@Test(groups = { "detectTriangle" }, dataProvider = "2equalSides")
	public void detectTriangleTwoEqualSides(double a, double b, double c) {
		triangle = new Triangle(a, b, c);
		Assert.assertEquals(triangle.detectTriangle(), TR_ISOSCELES, 0.01);
	}
	
	@DataProvider (name = "correctSquare")
	public Object[][] getSquareCorrectSquare() {
	return new Object[][] {
	{ 3, 4, 5, 36 },
	};
	}
	
	@Test(groups = { "getSquare" }, dataProvider = "correctSquare")
	public void getSquareCorrectSidess(double a, double b, double c, double square) {
		triangle = new Triangle(a, b, c);
		Assert.assertEquals(triangle.getSquare(), square);
	}

	
	
}
