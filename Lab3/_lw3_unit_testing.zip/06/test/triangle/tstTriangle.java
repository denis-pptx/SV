
import org.testng.Assert;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;
import triangle.Triangle;

public class tstTriangle {
    @DataProvider(name = "DataForDetectTringle")
    public Object[][] createDataForDetectTringle(){
        return new Object[][]{
                {new Double(1), new Double(1), new Double(1), new Integer(0b0011)},
                {new Double(2), new Double(2), new Double(1), new Integer(0b0010)},
                {new Double(2), new Double(5), new Double(6), new Integer(0b0100)},
                {new Double(4), new Double(5), new Double(6), new Integer(0b1000)},
                {new Double(0), new Double(0), new Double(0), new Integer(0b0000)},
                {new Double(-3), new Double(-3), new Double(-3), new Integer(0b0000)},
                {new Double(1), new Double(2), new Double(3), new Integer(0b0000)}
        };
    }

    @DataProvider(name = "DataForCheckTringle")
    public Object[][] createDataForCheckTringle(){
        return new Object[][]{
                {new Double(1), new Double(1), new Double(1), true},
                {new Double(2), new Double(2), new Double(1), true},
                {new Double(2), new Double(5), new Double(6), true},
                {new Double(4), new Double(5), new Double(6), true},
                {new Double(0), new Double(0), new Double(0), false},
                {new Double(-3), new Double(-3), new Double(-3), false},
                {new Double(1), new Double(2), new Double(3), false}
        };
    }

    @DataProvider(name = "negativeData")
    public Object[][] createNegativeData(){
        return new Object[][]{
                {new Double(4), new Double(-1), new Double(3)},
                {new Double(1), new Double(2), new Double(3)},
                {new Double(2), new Double(5), new Double(6)},
                {new Double(0), new Double(0), new Double(0)},
                {new Double(-3), new Double(-3), new Double(-3)}
        };
    }



    @Test (dataProvider = "DataForDetectTringle")
    public void testDetectTringle(double a, double b, double c, int exp){
        Triangle triangle = new Triangle(a, b, c);
        Assert.assertEquals(triangle.detectTriangle(), exp);
    }

    @Test(dataProvider = "DataForCheckTringle")
    public void testCheckTriangle(double a, double b, double c, boolean exp){
        Triangle triangle = new Triangle(a, b, c);
        Assert.assertEquals(triangle.checkTriangle(), exp);
    }

    @Test(dataProvider = "negativeData", expectedExceptions = ArithmeticException.class)
    public void testGetSquare(double a, double b, double c){
        Triangle triangle = new Triangle(a, b, c);
        triangle.getSquare();
    }
}
