
import org.testng.Assert;
import org.testng.annotations.AfterTest;
import org.testng.annotations.Test;

public class NewTestSquare {
	private Triangle tr;

	@AfterTest
		public void testFinalisation() {
			this.tr = null;
		}

	@Test
	  public void f1() {
		  this.tr = new Triangle(6, 8, 10);
		  Assert.assertEquals(24.0, this.tr.getSquare());
	  }
	
	@Test(expectedExceptions=IllegalArgumentException.class)
	  public void f2() {
		  this.tr = new Triangle(3, 4, 0);
		  Assert.assertEquals(0.0, this.tr.getSquare());
	  }
	
	@Test(expectedExceptions=IllegalArgumentException.class)
	  public void f3() {
		  this.tr = new Triangle(0, 4, 5);
		  Assert.assertEquals(0.0, this.tr.getSquare());
	  }
	
	@Test(expectedExceptions=IllegalArgumentException.class)
	  public void f4() {
		  this.tr = new Triangle(3, 0, 5);
		  Assert.assertEquals(0.0, this.tr.getSquare());
	  }
	
	@Test(expectedExceptions=IllegalArgumentException.class)
	  public void f5() {
		  this.tr = new Triangle(-1, 4, 5);
		  Assert.assertEquals(0.0, this.tr.getSquare());
	  }
	
	@Test(expectedExceptions=IllegalArgumentException.class)
	  public void f6() {
		  this.tr = new Triangle(4, -1, 5);
		  Assert.assertEquals(0.0, this.tr.getSquare());
	  }
	
	@Test(expectedExceptions=IllegalArgumentException.class)
	  public void f7() {
		  this.tr = new Triangle(3, 4, -5);
		  Assert.assertEquals(0.0, this.tr.getSquare());
	  }
	
	@Test(expectedExceptions=IllegalArgumentException.class)
	  public void f8() {
		  this.tr = new Triangle(1, 3, 5);
		  Assert.assertEquals(0.0, this.tr.getSquare());
	  }
	
	@Test(expectedExceptions=IllegalArgumentException.class)
	  public void f9() {
		  this.tr = new Triangle(1, 5, 3);
		  Assert.assertEquals(0.0, this.tr.getSquare());
	  }
	
	@Test(expectedExceptions=IllegalArgumentException.class)
	  public void f10() {
		  this.tr = new Triangle(5, 3, 1);
		  Assert.assertEquals(0.0, this.tr.getSquare());
	  }
	
}
