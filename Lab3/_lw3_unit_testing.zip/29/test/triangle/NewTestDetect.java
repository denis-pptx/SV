
import org.testng.Assert;
import org.testng.annotations.AfterTest;
import org.testng.annotations.Test;

public class NewTestDetect {
	private Triangle tr;

	@AfterTest
		public void testFinalisation() {
			this.tr = null;
		}

	@Test
	  public void f1() {
		  this.tr = new Triangle(4, 6, 5);
		  Assert.assertEquals(4, this.tr.detectTriangle());
	  }
	
	@Test
	  public void f2() {
		  this.tr = new Triangle(4, 6, 4);
		  Assert.assertEquals(2, this.tr.detectTriangle());
	  }
	
	@Test
	  public void f3() {
		  this.tr = new Triangle(4, 4, 4);
		  Assert.assertEquals(1,2, this.tr.detectTriangle());
	  }
	
	@Test
	  public void f4() {
		  this.tr = new Triangle(6, 4, 4);
		  Assert.assertEquals(2, this.tr.detectTriangle());
	  }
	
	@Test
	  public void f5() {
		  this.tr = new Triangle(4, 4, 6);
		  Assert.assertEquals(2, this.tr.detectTriangle());
	  }
	
	@Test(expectedExceptions=IllegalArgumentException.class)
	  public void f6() {
		  this.tr = new Triangle(0, 3, 2);
		  Assert.assertEquals(4, this.tr.detectTriangle());
	  }
	
	@Test(expectedExceptions=IllegalArgumentException.class)
	  public void f7() {
		  this.tr = new Triangle(3, 0, 2);
		  Assert.assertEquals(4, this.tr.detectTriangle());
	  }
	
	@Test(expectedExceptions=IllegalArgumentException.class)
	  public void f8() {
		  this.tr = new Triangle(3, 2, 0);
		  Assert.assertEquals(4, this.tr.detectTriangle());
	  }
	
	@Test(expectedExceptions=IllegalArgumentException.class)
	  public void f9() {
		  this.tr = new Triangle(-2, 3, 2);
		  Assert.assertEquals(2, this.tr.detectTriangle());
	  }
	
	@Test(expectedExceptions=IllegalArgumentException.class)
	  public void f10() {
		  this.tr = new Triangle(3, -2, 5);
		  Assert.assertEquals(2, this.tr.detectTriangle());
	  }
	
	
	@Test(expectedExceptions=IllegalArgumentException.class)
	  public void f11() {
		  this.tr = new Triangle(2, 2, -2);
		  Assert.assertEquals(1,2, this.tr.detectTriangle());
	  }
	
	@Test(expectedExceptions=IllegalArgumentException.class)
	  public void f12() {
		  this.tr = new Triangle(1, 10, 1);
		  Assert.assertEquals(2, this.tr.detectTriangle());
	  }
	
	@Test(expectedExceptions=IllegalArgumentException.class)
	  public void f13() {
		  this.tr = new Triangle(1, 3, 5);
		  Assert.assertEquals(4, this.tr.detectTriangle());
	  }
	
	@Test
	  public void f14() {
		  this.tr = new Triangle(4, 5, 3);
		  Assert.assertEquals(8, this.tr.detectTriangle());
	  }
	
	@Test
	  public void f15() {
		  this.tr = new Triangle(3, 4, 5);
		  Assert.assertEquals(8, this.tr.detectTriangle());
	  }
	
	@Test
	  public void f16() {
		  this.tr = new Triangle(5, 3, 4);
		  Assert.assertEquals(8, this.tr.detectTriangle());
	  }
	
}
