
import org.testng.Assert;
import org.testng.annotations.AfterTest;
import org.testng.annotations.Test;

public class NewTestCheck {
	private Triangle tr;

	@AfterTest
		public void testFinalisation() {
			this.tr = null;
		}

	@Test
	  public void f1() {
		  this.tr = new Triangle(4, 6, 5);
		  Assert.assertTrue(this.tr.checkTriangle());
		  Assert.assertEquals("", this.tr.getMessage());
	  }
	  
	  @Test
	  public void f2() {
		  tr = new Triangle(1, 3, 5);
		  Assert.assertFalse(this.tr.checkTriangle());
		  Assert.assertEquals("a+b<=c", this.tr.getMessage());
	  }
	  
	  @Test
	  public void f3() {
		  tr = new Triangle(0, 3, 5);
		  Assert.assertFalse(this.tr.checkTriangle());
		  Assert.assertEquals("a<=0", this.tr.getMessage());
	  }
	  
	  @Test
	  public void f4() {
		  tr = new Triangle(1, 0, 5);
		  Assert.assertFalse(this.tr.checkTriangle());
		  Assert.assertEquals("b<=0", this.tr.getMessage());
	  }
	  
	  @Test
	  public void f5() {
		  tr = new Triangle(1, 3, 0);
		  Assert.assertFalse(this.tr.checkTriangle());
		  Assert.assertEquals("c<=0", this.tr.getMessage());
	  }
	   
	  @Test
	  public void f6() {
		  tr = new Triangle(-3, 4, 5);
		  Assert.assertFalse(this.tr.checkTriangle());
		  Assert.assertEquals("a<=0", this.tr.getMessage());
	  }
	  
	  @Test
	  public void f7() {
		  tr = new Triangle(3, -4, 5);
		  Assert.assertFalse(this.tr.checkTriangle());
		  Assert.assertEquals("b<=0", this.tr.getMessage());
	  }
	  
	  @Test
	  public void f8() {
		  tr = new Triangle(3, 4, -1);
		  Assert.assertFalse(this.tr.checkTriangle());
		  Assert.assertEquals("c<=0", this.tr.getMessage());
	  }
	  
	  @Test
	  public void f9() {
		  tr = new Triangle(1, 5, 3);
		  Assert.assertFalse(this.tr.checkTriangle());
		  Assert.assertEquals("a+c<=b", this.tr.getMessage());
	  }
	  
	  @Test
	  public void f10() {
		  tr = new Triangle(5, 1, 3);
		  Assert.assertFalse(this.tr.checkTriangle());
		  Assert.assertEquals("b+c<=a", this.tr.getMessage());
	  }
}
