
import org.testng.Assert;
import triangle.Triangle;
import org.testng.annotations.Test;


public class tstDetectTriangle {

    @Test
    public void testOrdinaryTriangle() {
        final int TR_ORDYNARY = 4;
        Triangle triangle = new Triangle(2, 3, 4);
        Assert.assertEquals(triangle.detectTriangle(), TR_ORDYNARY);
    }

    @Test
    public void testNegativeSideOrdinaryTriangle() {
        final int TR_ORDYNARY = 4;
        Triangle triangle = new Triangle(2, 3, -4);
        Assert.assertNotEquals(triangle.detectTriangle(), TR_ORDYNARY, "The sides can NOT be negative.");
    }

    @Test
    public void testNullSideOrdinaryTriangle() {
        final int TR_ORDYNARY = 4;
        Triangle triangle = new Triangle(2, 0, 4);
        Assert.assertNotEquals(triangle.detectTriangle(), TR_ORDYNARY, "The sides can NOT be equal 0.");
    }

    @Test
    public void testEquilateralTriangle() {
        final int TR_EQUILATERAL = 1;
        final int TR_ISOSCELES = 2;
        Triangle triangle = new Triangle(1, 1, 1);
        Assert.assertEquals(triangle.detectTriangle(), ( TR_ISOSCELES|TR_EQUILATERAL ));
    }

    @Test
    public void testNegativeSidesEquilateral() {
        final int TR_EQUILATERAL = 1;
        final int TR_ISOSCELES = 2;
        Triangle triangle = new Triangle(-1, 1, 1);
        Assert.assertNotEquals(triangle.detectTriangle(), (TR_EQUILATERAL | TR_ISOSCELES),
                "The sides can NOT be negative. ");
    }

    @Test
    public void testNullSidesEquilateral() {
        final int TR_RECTANGULAR = 8;
        final int TR_EQUILATERAL = 1;
        final int TR_ISOSCELES = 2;
        Triangle triangle = new Triangle(1, 0, 1);
        Assert.assertNotEquals(triangle.detectTriangle(), (TR_EQUILATERAL | TR_ISOSCELES | TR_RECTANGULAR),
                "The sides can NOT equal 0. ");
    }

    @Test
    public void testIsosceles() {
        final int TR_ISOSCELES = 2;
        Triangle triangle = new Triangle(6, 6, 4);
        Assert.assertEquals(triangle.detectTriangle(), TR_ISOSCELES);
    }

    @Test
    public void testIsoscelesNegativeA() {
        final int TR_ISOSCELES = 2;
        Triangle triangle = new Triangle(-6, 6, 4);
        Assert.assertNotEquals(triangle.detectTriangle(), TR_ISOSCELES, "The sides can NOT be negative (a<0)");
    }

    @Test
    public void testIsoscelesNegativeB() {
        final int TR_ISOSCELES = 2;
        Triangle triangle = new Triangle(6, -6, 4);
        Assert.assertNotEquals(triangle.detectTriangle(), TR_ISOSCELES, "The sides can NOT be negative (b<0)");
    }

    @Test
    public void testIsoscelesNegativeC() {
        final int TR_ISOSCELES = 2;
        Triangle triangle = new Triangle(6, 6, -4);
        Assert.assertNotEquals(triangle.detectTriangle(), TR_ISOSCELES, "The sides can NOT be negative (c<0)");
    }

    @Test
    public void testNullSidesIsosceles() {
        final int TR_ISOSCELES = 2;
        final int TR_RECTANGULAR = 8;
        Triangle triangle = new Triangle(4, 4, 0);
        Assert.assertNotEquals(triangle.detectTriangle(), TR_ISOSCELES, "The sides can NOT be equal 0. ");
    }

    @Test
    public void testRectangular() {
        final int TR_RECTANGULAR = 8;
        Triangle triangle = new Triangle(5, 4, 3);
        Assert.assertEquals(triangle.detectTriangle(), TR_RECTANGULAR);
    }

    @Test
    public void testNegativeSidesRectangular() {
        final int TR_RECTANGULAR = 8;
        Triangle triangle = new Triangle(5, -4, 3);
        Assert.assertNotEquals(triangle.detectTriangle(), TR_RECTANGULAR, "The sides can NOT be negative. ");
    }

    @Test
    public void testIsoscelesRectangular() {
        final int TR_RECTANGULAR = 8;
        final int TR_ISOSCELES = 2;
        Triangle triangle = new Triangle(2.0, 2.0, Math.sqrt(8));
        Assert.assertEquals(triangle.detectTriangle(), (TR_ISOSCELES | TR_RECTANGULAR), 0.01);
    }

    @Test
    public void testNegativeSidesIsoscelesRectangular() {
        final int TR_RECTANGULAR = 8;
        final int TR_ISOSCELES = 2;
        Triangle triangle = new Triangle(2.0, -2.0, Math.sqrt(8));
        Assert.assertNotEquals(triangle.detectTriangle(), (TR_RECTANGULAR | TR_ISOSCELES),
                "The sides can NOT be negative. ");
    }
}
