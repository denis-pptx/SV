
import org.testng.Assert;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;
import triangle.Triangle;
import java.util.ArrayList;
import java.util.Arrays;

public class tstCheckTriangle {
    @DataProvider(name = "sidesDataProvider")
    public Object[][] createData() {
        return new Object[][]{
                // test positive sides that are a triangle
                {true, new ArrayList<Double>(Arrays.asList(2.0, 3.0, 4.0))},
                // test negative sides
                {false, new ArrayList<Double>(Arrays.asList(-3.0, 3.0, 3.0))},
                {false, new ArrayList<Double>(Arrays.asList(3.0, -3.0, 3.0))},
                {false, new ArrayList<Double>(Arrays.asList(3.0, -3.0, -3.0))},
                // test sides = 0
                {false, new ArrayList<Double>(Arrays.asList(0.0, 3.0, 3.0))},
                {false, new ArrayList<Double>(Arrays.asList(3.0, 0.0, 3.0))},
                {false, new ArrayList<Double>(Arrays.asList(3.0, 3.0, 0.0))},
                // sum of 2 sides is less than 3 side
                {false, new ArrayList<Double>(Arrays.asList(1.0, 3.0, 8.0))},
                {false, new ArrayList<Double>(Arrays.asList(3.0, 8.0, 1.0))},
                {false, new ArrayList<Double>(Arrays.asList(8.0, 1.0, 3.0))},
                // sum of 2 sides is equal to 3 side
                {false, new ArrayList<Double>(Arrays.asList(1.0, 1.0, 2.0))},
                {false, new ArrayList<Double>(Arrays.asList(1.0, 2.0, 1.0))},
                {false, new ArrayList<Double>(Arrays.asList(2.0, 1.0, 1.0))},
        };
    }

    @Test(dataProvider = "sidesDataProvider")
    public void testSides(boolean exp, ArrayList<Double> parameters) {
        Double a = (Double) parameters.get(0);
        Double b = (Double) parameters.get(1);
        Double c = (Double) parameters.get(2);
        Triangle triangle = new Triangle(a, b, c);
        Assert.assertEquals(triangle.checkTriangle(), exp);
    }
}
