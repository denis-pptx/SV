
import org.testng.Assert;
import triangle.Triangle;
import org.testng.annotations.Test;

public class tstGetSquare {

    @Test
    public void testPositiveSidesSquare() {
        Triangle triangle = new Triangle(8, 10, 6.0);
        Assert.assertEquals(triangle.getSquare(), 24.0);
    }

    @Test
    public void testNegativeSideSquare() {
        Triangle triangle = new Triangle(-6.0, 8.0, 10.0);
        Assert.assertNotEquals(triangle.getSquare(), 24.0);
    }

    @Test
    public void testNullSideSquare() {
        Triangle triangle = new Triangle(4, 0, 2);
        Assert.assertTrue(0 < triangle.getSquare());
    }

    @Test
    public void testNotSidesSquare() {
        Triangle triangle = new Triangle(2, 5, 1);
        Assert.assertTrue(triangle.getSquare() > 0);
    }
}
