

import org.testng.annotations.DataProvider;

public class FactoryForCheckerNegative {
    @org.testng.annotations.Factory(dataProvider = "dataFlow2")
    public Object[] initFactory(String message, double v1, double v2, double v3) {
        return new Object[]{
                new tstTriangleCheckerNegative(message, v1, v2, v3),
        };
    }

    @DataProvider(name = "dataFlow2")
    public Object[][] initdata() {
        return new Object[][]{
                new Object[]{"incorrect data", 0.0, 0.0, 0.0},//incorrect data all numbers are zero

                new Object[]{"a=0", 0.0, 1.0, 2.0},//a=0
                new Object[]{"b=0", 1.0, 0.0, 2.0},//b=0
                new Object[]{"c=0", 1.0, 2.0, 0.0},//c=0


                new Object[]{"incorrect data", -2.0, -2.0, -2.0},//incorrect data all numbers are negative

                new Object[]{"a<0", -2.0, 2.0, 2.0},//a<0
                new Object[]{"b<0", 2.0, -1.0, 3.0},//b<0
                new Object[]{"c<0", 2.0, 1.0, -1.0},//c<0

                new Object[]{"a+b=c", 3.0, 2.0, 5.0},//a+b=c
                new Object[]{"a+c=b", 2.0, 6.0, 4.0},//a+c=b
                new Object[]{"b+c=a", 9.0, 4.0, 5.0},// b+c=a

                new Object[]{"a+b<=c", 3.0, 2.0, 6.0},//a+b<c
                new Object[]{"a+c<=b", 2.0, 7.0, 4.0},//a+c<b
                new Object[]{"b+c<=a", 10.0, 4.0, 5.0},// b+c<a
        };
    }

}
