

import org.testng.TestNG;
import org.testng.xml.Parser;
import org.testng.xml.XmlSuite;
import org.xml.sax.SAXException;

import javax.xml.parsers.ParserConfigurationException;
import java.io.IOException;

public class RunnerWithParser {
    public static void main(String[] args) throws IOException, SAXException, ParserConfigurationException {
        String file = "./testNG.xml";
        TestNG testNG = new TestNG();
        for (XmlSuite suite : new Parser(file).parseToList()) {
            testNG.setCommandLineSuite(suite);
        }
        testNG.run();
    }
}
