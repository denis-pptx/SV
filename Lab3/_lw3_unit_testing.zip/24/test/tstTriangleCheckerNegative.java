
import main.triangle.Triangle;
import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

public class tstTriangleCheckerNegative {
    private Triangle trinagle;
    private double sideA;
    private double sideB;
    private double sideC;
    private String mesagge;

    public tstTriangleCheckerNegative(String message, double sideA, double sideB, double sideC) {
        this.sideA = sideA;
        this.sideB = sideB;
        this.sideC = sideC;
        this.mesagge = message;
    }

    @BeforeMethod(description = "Init Triangle", groups = "Negative")
    public void init() {
        trinagle = new Triangle(sideA, sideB, sideC);
    }
    @AfterMethod
    public void cleanUp() {
        trinagle = null;
    }

    @Test(description = "check response from the checker", groups = "Negative")
    public void checkCheckerInputData() {
        Assert.assertFalse(trinagle.checkTriangle(), "issue with response from checker");
    }

    @Test(description = "check record data in var message after rich out to the checker", groups = "Negative")
    public void checkUsingVarMessage() {
        trinagle.checkTriangle();
        Assert.assertEquals(trinagle.getMessage(), this.mesagge,
                "issue with recording in var message " + sideA + ";" + sideB + ";" + sideC);
    }

}
