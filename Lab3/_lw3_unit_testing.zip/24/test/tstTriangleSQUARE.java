
import main.triangle.Triangle;
import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

public class tstTriangleSQUARE {
    private Triangle trinagle;
    private double sideA;
    private double sideB;
    private double sideC;
    double p = (sideA + sideB + sideC) / 2;
    double square =  Math.sqrt(p * (p - sideA) * (p - sideB) * (p - sideC));


    public tstTriangleSQUARE(double sideA, double sideB, double sideC) {
        this.sideA = sideA;
        this.sideB = sideB;
        this.sideC = sideC;
    }

    @BeforeMethod(description = "Init Triangle", groups = "Positive")
    public void init() {
        trinagle = new Triangle(sideA, sideB, sideC);
    }

    @AfterMethod(description = "Clean Up, Kill triangle", groups = "Positive")
    public void cleanUp() {
        trinagle = null;
    }

    @Test(description = "check Square", groups = "Positive")
    public void checkSquare() {
        Assert.assertEquals(trinagle.getSquare(),this.square,"issue with calculating square of triangle");
    }

}
