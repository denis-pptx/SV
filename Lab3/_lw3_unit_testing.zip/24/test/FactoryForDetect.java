

import org.testng.annotations.DataProvider;

public class FactoryForDetect {
    @org.testng.annotations.Factory(dataProvider = "dataFlow")
    public Object[] initFactory(int type, double v1, double v2, double v3) {
        return new Object[]{
                new tstTriangleDETECT(type, v1, v2, v3),
        };
    }

    @DataProvider(name = "dataFlow")
    public Object[][] initdata() {
        return new Object[][]{
                new Object[]{1, 2.0, 2.0, 2.0},//равносторонний

                new Object[]{2, 2.0, 2.0, 3.0},//равнобедренный
                new Object[]{2, 2.0, 3.0, 3.0},//равнобедренный
                new Object[]{2, 3.0, 2.0, 3.0},//равнобедренный

                new Object[]{4, 2.0, 3.0, 4.0},//обычный

                new Object[]{8, 3.0, 4.0, 5.0},// прямоугольный
        };
    }

}
