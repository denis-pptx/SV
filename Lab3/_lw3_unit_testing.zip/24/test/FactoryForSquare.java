

import org.testng.annotations.DataProvider;

public class FactoryForSquare {
    @org.testng.annotations.Factory(dataProvider = "dataFlow3")
    public Object[] initFactory(double v1, double v2, double v3) {
        return new Object[]{
                new tstTriangleSQUARE(v1, v2, v3),
        };
    }

    @DataProvider(name = "dataFlow3")
    public Object[][] initdata() {
        return new Object[][]{
                new Object[]{ 2.0, 3.0, 1.0},
        };
    }

}
