

import org.testng.annotations.DataProvider;

public class FactoryForCheckerPositive {
    @org.testng.annotations.Factory(dataProvider = "dataFlow2")
    public Object[] initFactory(String message, double v1, double v2, double v3) {
        return new Object[]{
                new tstTriangleCheckerPositive(message, v1, v2, v3),
        };
    }

    @DataProvider(name = "dataFlow2")
    public Object[][] initdata() {
        return new Object[][]{
                new Object[]{"", 2.0, 3.0, 4.0},
        };
    }

}
