
import main.triangle.Triangle;
import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

public class tstTriangleDETECT {
    private Triangle trinagle;
    private double sideA;
    private double sideB;
    private double sideC;
    private int expectedType;

    public tstTriangleDETECT(int type, double sideA, double sideB, double sideC) {
        this.sideA = sideA;
        this.sideB = sideB;
        this.sideC = sideC;
        this.expectedType = type;
    }

    @BeforeMethod(description = "Init Triangle", groups = "Positive")
    public void init() {
        trinagle = new Triangle(sideA, sideB, sideC);
    }

    @AfterMethod(description = "Clean Up, Kill triangle", groups = "Positive")
    public void cleanUp() {
        trinagle = null;
    }

    @Test(description = "check detection type of triangle", groups = "Positive")
    public void checkDetectTriangle() {
        Assert.assertEquals(trinagle.detectTriangle(), expectedType,
                "defect in detection of the triangle type with data " + sideA + ";" + sideB + ";" + sideC);
    }

}
