
import static org.junit.Assert.*;
import org.junit.Test;
import main.triangle.Triangle;

public class TestTriangle {

	Triangle trEquilateral = new Triangle(3.0, 3.0, 3.0);
	Triangle trIsosceles = new Triangle(1.0, 2.0, 2.0);
	Triangle trOrdinary = new Triangle(7.0, 3.5, 5.0);
	Triangle trRectangular = new Triangle(3.0, 4.0, 5.0);

	Triangle trIncorrect1 = new Triangle(-3, -5, 8);
	Triangle trIncorrect2 = new Triangle(-3, -5, 0);
	Triangle trIncorrect3 = new Triangle(0, 0, 0);

	@Test
	public void tstGetMessage() {
		assertNotNull(trEquilateral.getMessage());
		assertNotNull(trIsosceles.getMessage());
		assertNotNull(trOrdinary.getMessage());
		assertNotNull(trRectangular.getMessage());
	}

	// test of a constructor with a incorrect triangle parameters
	@Test
	public void tstConstructor1() {
		assertNotNull(trOrdinary.getMessage());
	}

	@Test
	public void tstConstructor2() {
		assertNotNull(new Triangle(6, 7, 7));
	}

	// check that message has been initialized
	@Test
	public void tstConstructor3() {
		assertNull(trOrdinary.getMessage());
	}

	// check that message has been initialized
	@Test(expected = NullPointerException.class)
	// @Ignore
	public void tstConstructor4() {
		trOrdinary.getMessage().intern();
	}

	// create triangle with incorrect parameters
	@Test(expected = IllegalArgumentException.class)
	// @Ignore
	public void tstConstructor5() {
		new Triangle(-1, -2, -3);
		new Triangle(0, 0, 0);
		new Triangle(1, 111, 213);
	}

	@Test
	public void tstCheckTriangle() {
		assertTrue(trEquilateral.checkTriangle());
		assertTrue(trIsosceles.checkTriangle());
		assertTrue(trOrdinary.checkTriangle());
		assertTrue(trRectangular.checkTriangle());
	}

	@Test
	public void tstCheckTriangleNegative1() {
		assertFalse(trIncorrect1.checkTriangle());
		assertEquals("", trIncorrect1.getMessage());
	}

	@Test
	public void tstCheckTriangleNegative2() {
		assertFalse(trIncorrect2.checkTriangle());
		assertEquals("", trIncorrect2.getMessage());
	}

	// test of changing message when check of triangle fail
	@Test
	public void tstCheckTriangleNegative3() {
		trIncorrect1.checkTriangle();
		assertNotEquals("", trIncorrect1.getMessage());
		trIncorrect2.checkTriangle();
		assertNotEquals("", trIncorrect2.getMessage());
	}

	@Test
	public void tstDetectEqTriangle() {
		assertTrue(1 == trEquilateral.detectTriangle());
	}

	// check what triangle with incorrect parameters doesn't give correct
	// execution of a method
	@Test
	public void tstDetectEqTriangleNegative() {
		assertFalse(1 == trIncorrect1.detectTriangle());
	}

	@Test
	public void tstDetectIsoTriangle() {
		assertTrue(2 == trIsosceles.detectTriangle());
	}

	@Test
	public void tstDetectIsoTriangleNegative() {
		assertFalse(2 == trIncorrect1.detectTriangle());
	}

	@Test
	public void tstDetectOrdTriangle() {
		assertTrue(4 == trOrdinary.detectTriangle());
	}

	@Test
	public void tstDetectOrdTriangleNegative() {
		assertFalse(4 == trIncorrect2.detectTriangle());
	}

	@Test
	public void tstDetectRectTriangle() {
		assertTrue(8 == trRectangular.detectTriangle());
	}

	@Test
	public void tstDetectRectTriangleNegative() {
		assertFalse(8 == trIncorrect2.detectTriangle());
	}

	// feature combination
	@Test
	public void tstDetectCombTriangle() {
		assertTrue(!(1 == trEquilateral.detectTriangle()) && !(2 == trEquilateral.detectTriangle())
				&& !(4 == trEquilateral.detectTriangle()) && !(8 == trEquilateral.detectTriangle()));
	}

	@Test
	public void tstDetectCombTriangleNegative() {
		assertTrue(!(1 == trIncorrect1.detectTriangle()) && !(2 == trIncorrect1.detectTriangle())
				&& !(4 == trIncorrect1.detectTriangle()) && !(8 == trIncorrect1.detectTriangle()));
	}

	@Test
	public void tstGetSquarePositive() {
		assertNotNull(trOrdinary.getSquare());
		assertTrue(trOrdinary.getSquare() > 0);
	}

	@Test
	public void tstGetSquareNegative() {
		assertTrue(trOrdinary.getSquare() <= 0);
		assertNull(trOrdinary.getSquare());
	}
}
