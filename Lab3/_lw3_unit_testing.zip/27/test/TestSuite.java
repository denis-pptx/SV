
import org.junit.runner.RunWith;
import org.junit.runners.Suite;
import org.junit.runners.model.InitializationError;

@RunWith(Suite.class)

@Suite.SuiteClasses({
   TestTriangle.class
   
})
public class TestSuite extends Suite {

	protected TestSuite(Class<?> klass, Class<?>[] suiteClasses) throws InitializationError {
		super(klass, suiteClasses);		
	}
	
}
