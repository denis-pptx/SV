
import org.testng.Assert;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;


public class PositiveTests {
	//check correct equilateral triangle
	 private Triangle tr;
	 private int equilateral;
	
	@BeforeTest
	public void testPreparation() {
		this.tr = new Triangle(3.0, 3.0, 3.0);
		this.equilateral = tr.TR_EQUILATERAL;
	}
	
	@AfterTest
	public void testFinalisation() {
		this.tr = null;
	}
	
	@Test
	public void tstCorrectValues(){
		Assert.assertEquals(this.tr.detectTriangle(), this.equilateral);
	}
}