
import java.util.ArrayList;
import java.util.Arrays;

import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

public class CheckMethodCheckTriangleWithB {
	private Triangle tr;
	
	@AfterMethod
	public void objFinalisation() {
		this.tr = null;
	}
	
	@DataProvider(name = "dp")
	  public Object[][] dp() {
	    return new Object[][] {
	      {new ArrayList<Double>(Arrays.asList(1.0, -1.0, 3.0)), "b<=0"},
	      {new ArrayList<Double>(Arrays.asList(0.1, 0.0, 0.1)), "b<=0"},
	      {new ArrayList<Double>(Arrays.asList(999999999999.999999999999, -999999999999.999999999999, 999999999999.999999999999)), "b<=0"},
	    };
	  }
	
	  @Test(dataProvider = "dp")
	  public void tstCheckMethodWithSideA(ArrayList<Double> parameters, String marker) {
		  Double a = (Double) parameters.get(0);
		  Double b = (Double) parameters.get(1);
		  Double c = (Double) parameters.get(2);
		  
		  tr = new Triangle(a, b, c);
		  
		  // Value false is expected because side b <= 0
		  Assert.assertFalse(tr.checkTriangle());
	  }
}