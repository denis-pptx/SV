
import java.util.ArrayList;
import java.util.Arrays;

import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

public class CheckMethodCheckTriangleWithC {
private Triangle tr;
	
	@AfterMethod
	public void testFinalisation() {
		this.tr = null;
	}
	
	@DataProvider(name = "dp")
	  public Object[][] dp() {
	    return new Object[][] {
	      {new ArrayList<Double>(Arrays.asList(1.0, 1.0, -1.0)), "c<=0"},
	      {new ArrayList<Double>(Arrays.asList(0.0, 0.0, 0.0)), "c<=0"},
	      {new ArrayList<Double>(Arrays.asList(999999999999.999999999999, 999999999999.999999999999, -999999999999.999999999999)), "c<=0"},
	    };
	  }
	
	  @Test(dataProvider = "dp")
	  public void tstCheckMethodWithSideA(ArrayList<Double> parameters, String marker) {
		  Double a = (Double) parameters.get(0);
		  Double b = (Double) parameters.get(1);
		  Double c = (Double) parameters.get(2);
		  
		  tr = new Triangle(a, b, c);
		  
		  // Value false is expected because side c <= 0
		  Assert.assertFalse(tr.checkTriangle());
	  }
}