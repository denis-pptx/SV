
import java.util.ArrayList;
import java.util.Arrays;

import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

public class CheckMethodGetSquare {
	private Triangle tr;
	
	@AfterMethod
	public void testFinalisation() {
		this.tr = null;
	}
	
	@DataProvider(name = "dp")
	  public Object[][] dp() {
	    return new Object[][] {
	      {new ArrayList<Double>(Arrays.asList(2.0, 2.0, 2.0))},
	      {new ArrayList<Double>(Arrays.asList(0.1, 0.1, 0.1))},
	      {new ArrayList<Double>(Arrays.asList(-2.0, -2.0, -2.0))},
	    };
	  }
	  
	  @Test(dataProvider = "dp")
	  public void tstIsoscelesTriangle(ArrayList<Double> parameters) {
		  // check Square of equilateral triangle
		  Double a = (Double) parameters.get(0);
		  Double b = (Double) parameters.get(1);
		  Double c = (Double) parameters.get(2);
		  tr = new Triangle(a, b, c);
		  double square = Math.sqrt(3.0)/4.0*Math.pow(a, 2); // check formula
		  System.out.println(square);
		  Assert.assertEquals(tr.getSquare(), square);
	  }
}