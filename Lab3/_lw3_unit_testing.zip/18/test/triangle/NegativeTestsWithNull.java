
import org.testng.Assert;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

public class NegativeTestsWithNull {
	private Triangle tr;
	private String message;
	
	@BeforeTest
	public void testPreparation() {
		this.tr = new Triangle(0.0, 0.0, 0.0);
	}
	
	@AfterTest
	public void testFinalisation() {
		this.tr = null;
	}
	
	@Test
	public void tstGetMessage()
	{
		this.tr.checkTriangle();
		this.message = tr.getMessage();
		Assert.assertEquals(this.message, "a<=0");
	}
	
	@Test
	public void tstCheckTriangle(){
		Assert.assertFalse(tr.checkTriangle());
	}
	
	@Test
	public void tstGetSquare(){
		Assert.assertEquals(0.0, tr.getSquare());
	}
	
}
