
import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

public class TestTriangleDetectTriangleMethod {
	private Triangle triange;

	@DataProvider(name = "DataForTst_detectTriangleMethod")
	public Object[][] createSomeData() {

		return new Object[][] { { 0, -1.0, 1.0, 1.0 }, // one of sides is <= 0;
				{ 0, 1.0, -1.0, 1.0 }, // one of sides is <= 0;
				{ 0, 1.0, 1.0, -1.0 }, // one of sides is <= 0;
				{ 0, -1.0, -1.0, -2.0 }, // all of sides are <= 0;
				{ 0, 2.5, 2.5, 10 }, // c>=a+b;
				{ 0, 10, 2.5, 2.5 }, // a>=c+b;
				{ 0, 2.5, 10, 2.5 }, // b>=a+c;
				{ 1, 2.5, 2.5, 2.5 }, // a=b=c - равносторонний;
				{ 2, 2.5, 2.5, 4.0 }, // a=b - равнобедренный;
				{ 2, 2.5, 5.0, 5.0 }, // с=b - равнобедренный;
				{ 2, 2.5, 4.0, 2.5 }, // a=с - равнобедренный;
				{ 8, 3.0, 4.0, 5.0 }, // a*2+b*2=c*2 - прямоугольный;
				{ 8, 5.0, 3.0, 4.0 }, // a*2=b*2+c*2 - прямоугольный;
				{ 8, 3.0, 5.0, 4.0 }, // b*2=a*2+c*2 - прямоугольный;
				{ 4, 3.0, 5.0, 7.0 }, // a!=b!=c - обычный, удовлетворяющий
										// условиям (b<a+c and a<c+b and c<a+b);
				{ 4, 6.0, 8.0, 7.0 }, // a!=b!=c - обычный, удовлетворяющий
										// условиям (b<a+c and a<c+b and c<a+b);
				{ 4, 11.0, 5.5, 8.1 }, // a!=b!=c - обычный, удовлетворяющий
										// условиям (b<a+c and a<c+b and c<a+b);
				{ 4, Double.MAX_VALUE, Double.MAX_VALUE - 1, Double.MAX_VALUE - 2 }, // max
																						// and
																						// almost
																						// Max
				{ 0, Double.POSITIVE_INFINITY, Double.POSITIVE_INFINITY, Double.POSITIVE_INFINITY },
				{ 0, Double.NaN, Double.NaN, Double.NaN }
		};
	}

	@Test(dataProvider = "DataForTst_detectTriangleMethod")
	public void tst_detectTriangleMethod(int kindOfTriangle, double a, double b, double c) {
		triange = new Triangle(a, b, c);
		Assert.assertEquals(triange.detectTriangle(), kindOfTriangle);
	}

	@AfterMethod
	public void beforeMethod() {
		triange = null;
	}
}
