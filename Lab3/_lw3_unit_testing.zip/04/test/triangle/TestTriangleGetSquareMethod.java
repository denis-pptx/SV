
import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

public class TestTriangleGetSquareMethod {
	private Triangle triange;

	@DataProvider(name = "DataForTst_getSquareMethod")
	public Object[][] createSomeData() {

		return new Object[][] { { false, -1.0, 1.0, 1.0 }, // one of sides is <=
															// 0;
				{ false, 1.0, -1.0, 1.0 }, // one of sides is <= 0;
				{ false, 1.0, 1.0, -1.0 }, // one of sides is <= 0;
				{ false, -1.0, -1.0, -2.0 }, // all of sides are <= 0;
				{ false, 2.5, 2.5, 10 }, // c>=a+b;
				{ false, 10, 2.5, 2.5 }, // a>=c+b;
				{ false, 2.5, 10, 2.5 }, // b>=a+c;
				{ true, 2.5, 2.5, 2.5 }, // a=b=c - равносторонний;
				{ true, 2.5, 2.5, 4.0 }, // a=b - равнобедренный;
				{ true, 2.5, 5.0, 5.0 }, // с=b - равнобедренный;
				{ true, 2.5, 4.0, 2.5 }, // a=с - равнобедренный;
				{ true, 3.0, 4.0, 5.0 }, // a*2+b*2=c*2 - прямоугольный;
				{ true, 5.0, 3.0, 4.0 }, // a*2=b*2+c*2 - прямоугольный;
				{ true, 3.0, 5.0, 4.0 }, // b*2=a*2+c*2 - прямоугольный;
				{ true, 3.0, 5.0, 7.0 }, // a!=b!=c - обычный, удовлетворяющий
											// условиям (b<a+c and a<c+b and
											// c<a+b);
				{ true, 6.0, 8.0, 7.0 }, // a!=b!=c - обычный, удовлетворяющий
											// условиям (b<a+c and a<c+b and
											// c<a+b);
				{ true, 11.0, 5.5, 8.1 }, // a!=b!=c - обычный, удовлетворяющий
											// условиям (b<a+c and a<c+b and
											// c<a+b);
				{ true, Double.MAX_VALUE, Double.MAX_VALUE - 1, Double.MAX_VALUE - 2 }, // max
																						// and
																						// almost
																						// max

				{ false, Double.POSITIVE_INFINITY, Double.POSITIVE_INFINITY, Double.POSITIVE_INFINITY },
				{ false, Double.NaN, Double.NaN, Double.NaN } };
	}

	@Test(dataProvider = "DataForTst_getSquareMethod")
	public void tst_getSquareMethod(boolean bul, double a, double b, double c) {
		double square = 0;
		triange = new Triangle(a, b, c);
		try {
			square = triange.getSquare();
		} catch (ArithmeticException e) {
			Assert.fail("Square can't be less than zero");
		}
		Assert.assertTrue((square > 0) & (bul));
	}

	@AfterMethod
	public void beforeMethod() {
		triange = null;
	}
}
